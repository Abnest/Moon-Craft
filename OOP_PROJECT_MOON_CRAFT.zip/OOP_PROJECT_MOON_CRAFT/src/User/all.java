/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;
import Terrans.Barrack;
import Terrans.Builder;
import Terrans.Bunker;
import Terrans.CommandCenter;
import Terrans.Factory;
import Terrans.Hellion;
import Terrans.Marine;
import Terrans.MissileTurret;
import Terrans.Reaper;
import Terrans.SeigeTank;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Youssef-Abnest
 */
    public class all implements Serializable
     {
        public int MaxSmallUnits=20;
        public int MaxSmallBuildings=5;
        public int MaxBigBuildings=2;
        public int MaxCommanadCenters=3;
	public ArrayList <Builder> BS=new ArrayList();
        public ArrayList <Reaper> R=new ArrayList();
        public ArrayList <Marine> M=new ArrayList() ;
        public ArrayList <Hellion> H=new ArrayList();
        public ArrayList <SeigeTank> ST=new ArrayList();
        public ArrayList <CommandCenter> CdCr=new ArrayList();
	public ArrayList <Barrack> BK=new ArrayList();
	public ArrayList <Factory> FY=new ArrayList();
	public ArrayList <Bunker> BR=new ArrayList();
	public ArrayList <MissileTurret> MT=new ArrayList();
    }