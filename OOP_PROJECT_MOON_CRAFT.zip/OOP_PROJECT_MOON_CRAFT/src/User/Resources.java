/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import Manage_files.EncryptionDecryption;
import Terrans.Gas;
import Terrans.Mineral;
import Terrans.Terran;
import java.io.Serializable;

public class Resources implements Serializable{

	private String Minerals;
	private String Gas;
        private String absMinerals ;
        private String absGas ;
        private boolean check = true;
        private EncryptionDecryption EDResources = new EncryptionDecryption();
        public Resources()
        {
            if(check){
            Minerals = EDResources.Encrypt("10000",1);
            Gas = EDResources.Encrypt("10000",1);
            absMinerals = EDResources.Encrypt("10000",1);
            absGas = EDResources.Encrypt("10000",1);
            check = false;
            }
            
            else {
                Minerals = EDResources.Encrypt(Minerals,1);
                Gas = EDResources.Encrypt(Gas,1);
                absMinerals = EDResources.Encrypt(absMinerals,1);
                absGas = EDResources.Encrypt(absGas,1);
            }
        }
	public int getMinerals() {
       
		return Integer.parseInt(EDResources.Decrypt(Minerals, 1));
	}

	public void setMinerals(int m) {
            
		this.Minerals = EDResources.Encrypt(String.valueOf(m),1);
                
	}

	public int getGas() {
		return Integer.parseInt(EDResources.Decrypt(Gas, 1));
	}

	public void setGas(int g) {
		this.Gas = EDResources.Encrypt(String.valueOf(g),1);
	}
        //__________________________________________________________________________
        public int getabsMinerals() {
		return Integer.parseInt(EDResources.Decrypt(absMinerals, 1));
	}

	public void setabsMinerals(int m) {
		this.absMinerals = EDResources.Encrypt(String.valueOf(this.getabsMinerals()+m),1);
	}

	public int getabsGas() {
		return Integer.parseInt(EDResources.Decrypt(absGas, 1));
	}

	public void setabsGas(int g) {
		this.absGas = EDResources.Encrypt(String.valueOf(this.getabsGas()+g),1);
	}

	public void IncRescources(int minerals,int gas) {
		
		setMinerals(getMinerals() + minerals);
		setGas(getGas() + gas);
		
	}
        
        
        public void IncRescources(Resources R) {
		
		this.setMinerals(R.getMinerals());
		this.setGas(R.getGas());
		
	}
        public void IncMineral(Mineral M) {
		
		this.setMinerals(this.getMinerals()+M.decMineral());
		this.setabsMinerals(this.getMinerals()+M.decMineral());
		
	}
        public void IncGas(Gas G) {
	
		this.setGas(this.getGas()+G.decGas());
		this.setabsGas(this.getGas()+G.decGas());
	}
        

	public boolean BuyTerran(int M,int G) {
		
		if(DecRescources(M, G))
			return true;
		
		else return false;
		
	}

	public boolean CheckStorageMinerals() {
		
		if(this.getMinerals() > 0)
			return true;
		else return false;
	}
	
	public boolean CheckStorageGas() {
		
		if(this.getGas() > 0)
			return true;
		else return false;
	}
	public boolean DecRescources(int minerals,int gas) {
		
		if(CheckStorageMinerals() && CheckStorageGas()){
				
			if (minerals <= this.getMinerals() && gas <= this.getGas()){
                            this.setMinerals(this.getMinerals() - minerals);
                            this.setGas(this.getGas() - gas);
				return true;
			}
			
			else return false;
		}
		
		else return false;
	}
}