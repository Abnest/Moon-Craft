/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import GUI.Screens;

/**
 *
 * @author Youssef-Abnest
 */
public class Players {
   public static  Player P1 = Screens.P1;
    public static Player P2 = Screens.P2;
}
