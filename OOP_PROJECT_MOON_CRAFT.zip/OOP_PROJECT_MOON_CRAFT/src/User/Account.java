
package User;

import Manage_files.EncryptionDecryption;
import java.io.Serializable;

public class Account implements Serializable
{
        private String FirstName;
        private String LastName;
	private String UserName;
	private String Password;
	private EncryptionDecryption EDAccount= new EncryptionDecryption();  
        public Account ()
        {
            FirstName =  EDAccount.Encrypt(" ",1);
            LastName = EDAccount.Encrypt(" ",1);
        }
	public String getUserName() {
		return EDAccount.Decrypt(this.UserName,1);
	}   
	public boolean setUserName(String name) {
		if(name.charAt(0)>='0' &&name.charAt(0)<='9')
			return false;
		this.UserName= "";
		for(Integer i=0; i<name.length();i++)
			{
			
			if((name.charAt(i)>='a'&& name.charAt(i)<='z' )
				|| (name.charAt(i)>='A' && name.charAt(i)<='Z') 
				|| (name.charAt(i)>='0' &&name.charAt(i)<='9'))
			{
				this.UserName+= name.charAt(i);
				
			}
			else return false;
			}
                this.UserName=EDAccount.Encrypt(this.UserName,1);
		return true;
	}
        public String getFirstName() {
		return EDAccount.Decrypt(this.FirstName,1);
	}   
	public boolean setFirstName(String name) {
		if(name.charAt(0)>='0' &&name.charAt(0)<='9')
			return false;
		this.FirstName= "";
		for(Integer i=0; i<name.length();i++)
			{
			
			if((name.charAt(i)>='a'&& name.charAt(i)<='z' )
				|| (name.charAt(i)>='A' && name.charAt(i)<='Z') 
				|| (name.charAt(i)>='0' &&name.charAt(i)<='9'))
			{
				this.FirstName+= name.charAt(i);
				
			}
			else return false;
			}
                this.FirstName=EDAccount.Encrypt(this.FirstName,1);
		return true;
	}
        public String getLastName() {
		return EDAccount.Decrypt(this.LastName,1);
	}   
	public boolean setLastName(String name) {
		if(name.charAt(0)>='0' &&name.charAt(0)<='9')
			return false;
		this.LastName= "";
		for(Integer i=0; i<name.length();i++)
			{
			
			if((name.charAt(i)>='a'&& name.charAt(i)<='z' )
				|| (name.charAt(i)>='A' && name.charAt(i)<='Z') 
				|| (name.charAt(i)>='0' &&name.charAt(i)<='9'))
			{
				this.LastName+= name.charAt(i);
				
			}
			else return false;
			}
                this.LastName=EDAccount.Encrypt(this.LastName,1);
		return true;
	}
	public String getPassword() 
	{
		return EDAccount.Decrypt(this.Password,1);
	}

	public void setPassword(String password) 
	{
		this.Password=EDAccount.Encrypt(password,1);
	}

}
