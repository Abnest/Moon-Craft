package User;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Terrans.*;
import java.awt.Color;
import java.io.*;
import java.util.*;
public class Player implements Serializable{
 
        public all dum=new all();
	public ArrayList <AMove> IM;
	public ArrayList <IAttack> IA;
	public Account A;
	public Resources R;
        public Color ChoosenColor;
	public int kills;
	public Player()
	{
                IM = new ArrayList();
                IA = new ArrayList();
		A= new Account();
                R=new Resources();
                R.setGas(10000);
                R.setMinerals(10000);
                kills=0;
	}

	
	
}
