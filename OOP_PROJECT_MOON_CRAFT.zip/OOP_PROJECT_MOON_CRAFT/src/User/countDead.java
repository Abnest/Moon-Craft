/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import GUI.Screens;
import Terrans.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bringyyy
 */
public class countDead {
public void CalculatingKills()
{
    all mydum=Screens.P2.dum;
    Thread mykills= new Thread(){
        public void run()
        {
         while(true)
         {
             for(Barrack b:mydum.BK)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.BK.remove(b);
                 }
             
             for(Bunker b:mydum.BR)
                if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.BR.remove(b);
                 }
             for(Builder b:mydum.BS)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.BS.remove(b);
                 }
             for(CommandCenter b:mydum.CdCr)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.CdCr.remove(b);
                 }
             
             for(Factory b:mydum.FY)
                if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.FY.remove(b);
                 }
             
             for(Hellion b:mydum.H)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.H.remove(b);
                 }
             for(Marine b:mydum.M)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.M.remove(b);
                 }
             for(MissileTurret b:mydum.MT)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.MT.remove(b);
                 }
             
             for(Reaper b:mydum.R)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.R.remove(b);
                 }
             
             for(SeigeTank b:mydum.ST)
                 if(b.getHealth()<=0)
                 {
                     Screens.P1.kills++;
                     mydum.ST.remove(b);
                 }
             
             
             try {
                 sleep(1000);
             } catch (InterruptedException ex) 
             {}
         }
       }
    };
   mykills.start();
}
    
}
