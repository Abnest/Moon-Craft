package Terrans;

import User.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import GUI.*;



public class Builder extends  AMove {
    
	
	private JButton[] button = new JButton [5];	
	private JLabel[] label = new JLabel [3];
        private boolean Check = false;
        private String type ="";
	private JLabel blabla;
        
    public Builder(Color c)   
    {
            this.Team=c;
            this.setTName("Builder");
            this.setHealth(50);
            this.setMaxHealth(50);
            this.setMinerals(50);
            this.setGas(0);
            this.setSpeed(2);
            this.setInfo();this.setImage();
            this.alive=true;
    }
      public boolean setImage()
        {
    	 if (Team==ACC.P1.ChoosenColor)
          this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4390_raceSc2_normal.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
         if (Team==ACC.P2.ChoosenColor)
           this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4390_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));   
            this.setSize(50, 50);
            return true;
        }
      
            public void paint(Graphics g)
        {
            if(Check && type.equals("CommandCenter"))
            {
                Check = false;
                Screens.P1.dum.MaxSmallUnits+=20;
                Screens.P1.dum.MaxSmallBuildings+=5;
                Screens.P1.dum.MaxBigBuildings+=3;
                CommandCenter C = new CommandCenter(Team);
                Screens.P1.dum.CdCr.add(C);
                Screens.GM.Selected = Screens.P1.dum.CdCr.get(Screens.P1.dum.CdCr.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(C);
            
                revalidate();
           
            }
            
                if(Check && type.equals("Barrack"))
                {
                    Check = false;
                    Barrack B = new Barrack(Team);
                    Screens.P1.dum.BK.add(B);
                    Screens.GM.Selected = Screens.P1.dum.BK.get(Screens.P1.dum.BK.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                    Screens.GM.build(B);

                    revalidate();
           
                }
                        
                if(Check && type.equals("Factory")){
                Check = false;
                Factory F = new Factory(Team);
                Screens.P1.dum.FY.add(F);
                Screens.GM.Selected = Screens.P1.dum.FY.get(Screens.P1.dum.FY.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(F);
            
                revalidate();
           
              }
            
                if(Check && type.equals("Bunker")){
                Check = false;
                Bunker B = new Bunker(Team);
                Screens.P1.dum.BR.add(B);
                Screens.GM.Selected = Screens.P1.dum.BR.get(Screens.P1.dum.BR.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(B);
            
                revalidate();
           
              }
                                                
                if(Check && type.equals("MissileTurret")){
                Check = false;
                MissileTurret M = new MissileTurret(Team);
                Screens.P1.dum.MT.add(M);
                Screens.GM.Selected = Screens.P1.dum.MT.get(Screens.P1.dum.MT.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(M);
            
                revalidate();
           
              }

           
              
            
            super.paint(g);
            
        }
      
    public void setInfo()
  	{

  		this.Info = new JPanel();
  		this.Info.setLayout(new FlowLayout());
  		JPanel cont[]= new JPanel[2];
  		cont[0] = new JPanel(new FlowLayout());
		cont[1] = new JPanel(new FlowLayout());
  		button[0] = new JButton("Create CommandCenter");
  		button[1] = new JButton("Create Barrack");
  		button[2] = new JButton("Create Factory");
  		button[3] = new JButton("Create Bunker");
  		button[4] = new JButton("Create MissileTurret");
  		label[0] = new JLabel(this.getTName());
  		label[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
  		label[2] = new JLabel();
                if (Team==ACC.P1.ChoosenColor)
                label[2].setIcon(new ImageIcon(new ImageIcon ("Images\\Renders\\thumb_4390_raceSc2_normal.png").getImage().getScaledInstance(50,50 ,1)));
  
                if(Team==ACC.P2.ChoosenColor)
                label[2].setIcon(new ImageIcon(new ImageIcon ("Images\\Renders\\thumb_4390_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 ,1)));

                this.Info.add(cont[0]);
		this.Info.add(cont[1]);
		
		cont[0].add(label[2]);
		cont[0].add(label[0]);
		cont[0].add(label[1]);
		cont[1].add(button[0]);
		cont[1].add(button[1]);
		cont[1].add(button[2]);
		cont[1].add(button[3]);
		cont[1].add(button[4]);

            
            button[0].addActionListener(new Handler());
            button[1].addActionListener(new Handler());
            button[2].addActionListener(new Handler());
            button[3].addActionListener(new Handler());
            button[4].addActionListener(new Handler());
  	}
    	public boolean CreateCommandCenter(Player P)   
        {
            
            if(P.dum.CdCr.size()==P.dum.MaxCommanadCenters)
                return false;
            if (P.R.BuyTerran(400,150))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                P.dum.MaxSmallUnits+=20;
                P.dum.MaxSmallBuildings+=5;
                P.dum.MaxBigBuildings+=3;
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;
        }
	public boolean CreateBarrack(Player P)    
        {
         
              if(P.dum.BK.size()==P.dum.MaxBigBuildings)
                return false;
            if (P.R.BuyTerran(100,0))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;  
        }
        public boolean CreateFactory(Player P)    
        {
               
             if(P.dum.FY.size()==P.dum.MaxBigBuildings)
                return false;
            if (P.R.BuyTerran(100,75))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;  
	}
	public boolean CreateBunker(Player P)     
        {
              
           if(P.dum.BR.size()==P.dum.MaxSmallBuildings)
                return false;
            if (P.R.BuyTerran(75,75))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false; 
        }
	public boolean CreateMissileTurret(Player P)    
        {
	
           if(P.dum.MT.size()==P.dum.MaxSmallBuildings)
                return false;
            if (P.R.BuyTerran(100,25))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;  

        }
 
 
	public boolean repair(Terran T) 
        {
            if(T.getHealth()<T.getHealth())
            {
                T.setHealth(T.getHealth()+10);
                return true;
            }
            
            return false;
	}
        
        public void seekMinerals(Resources R, Mineral M)
        {
            this.changePosition(new Point(M.getX()+M.getWidth()+5,M.getY()+M.getHeight()+5));
            Thread seek= new Thread(){
                @Override
                  public void run()
                {   blabla=M;
                    while(M.getMCapacity()>0)
                    {
                        if (blabla!=M)
                           return;
                        R.IncMineral(M);
                        Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                        repaint();
                
                
                        try
                        {
                         sleep(4000);   
                        }
                    catch (InterruptedException ex) 
                        { }
                    }
                    if (blabla==M)
                    M.setVisible(false);
                }
            };
            seek.start();
            
        }
        
        public void seekGas(Resources R,Gas G)
        {
           this.changePosition(new Point(G.getX()+G.getWidth()+5,G.getY()+G.getHeight()+5));
            Thread seek= new Thread(){
                @Override
               public void run()
                {blabla=G;
                    while(G.getGCapacity()>0 && blabla==G)
                    {
                       if (blabla!=G)
                           return;
                        R.IncGas(G);
                         Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                          repaint();
                        try
                        {
                         sleep(4000);   
                        }
                    catch (InterruptedException ex) 
                        { }
                    }
                 if (blabla==G)
                    G.setVisible(false);
                }
            };
            seek.start();
        }
       
	
    	public class Handler implements ActionListener
    	{
    		
    		public void actionPerformed(ActionEvent e) {
    			
    			Object buttonPressed = e.getSource();
    			
    			if(buttonPressed == button[0]){
                                type = "CommandCenter";
    				if (Team==ACC.P1.ChoosenColor)
    				CreateCommandCenter(ACC.P1);
                        /*if (Team==ACC.P2.ChoosenColor)
    				CreateCommandCenter(ACC.P2);*/
    			}
    			
    			if(buttonPressed == button[1]){
                                type = "Barrack";
    				if (Team==ACC.P1.ChoosenColor)
    					CreateBarrack(ACC.P1);
    					/*if (Team==ACC.P2.ChoosenColor)
    					CreateBarrack(ACC.P2);*/
    			
    			}
    			
    			if(buttonPressed == button[2]){
                            type = "Factory";
    				if (Team==ACC.P1.ChoosenColor)
    					CreateFactory(ACC.P1);
    					/*if (Team==ACC.P2.ChoosenColor)
    					CreateFactory(ACC.P2);*/
    			
    			}
    			
    				
    			if(buttonPressed == button[3]){
                            type = "Bunker";
    				if (Team==ACC.P1.ChoosenColor)
    					CreateBunker(ACC.P1);
    					/*if (Team==ACC.P2.ChoosenColor)
    					CreateBunker(ACC.P2);
    			*/    			
    			}
    			
    			if(buttonPressed == button[4]){
                            type = "MissileTurret";
    				if (Team==ACC.P1.ChoosenColor)
    					CreateMissileTurret(ACC.P1);
    					/*if (Team==ACC.P2.ChoosenColor)
    					CreateMissileTurret(ACC.P2);
    			*/
    			
    			}
    			
    		}
    	}


        
     }
