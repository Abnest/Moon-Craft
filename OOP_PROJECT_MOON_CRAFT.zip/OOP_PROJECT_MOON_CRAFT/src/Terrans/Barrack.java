package Terrans;
import GUI.Screens;
import User.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Barrack extends Terran {
	
	private JButton[] button = new JButton [2];	
	private JLabel[] label = new JLabel [3];
	private boolean Check = false;
        private String type ="";
        
	public Barrack(Color c) 
        {
            this.Team=c;
            this.setTName("Barrack");
            this.setHealth(150);
            this.setMaxHealth(150);
            this.setMinerals(100);
            this.setGas(0);
            this.setInfo();this.setImage();
            
            this.alive=true;
        }
        public boolean setImage()
        {if(Team==ACC.P1.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5570_raceSc2_normal.png").getImage().getScaledInstance(125,125 ,1)));
            
            if(Team==ACC.P2.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5570_raceSc2_normal_2.png").getImage().getScaledInstance(125,125 ,1)));
            
            this.setSize(125, 125);
            return true;
        }
        
 public void paint(Graphics g)
        {
            if(Check && type.equals("Marine"))
            {
                                Check = false;
                Marine M = new Marine(Screens.P1.ChoosenColor);
                Screens.P1.dum.M.add(M);
                Screens.GM.Selected = Screens.P1.dum.M.get		(Screens.P1.dum.M.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(M);
            
                revalidate();
           
            }
            
                if(Check && type.equals("Reaper"))
                {
                    Check = false;
                    Reaper R = new Reaper(Screens.P1.ChoosenColor);
                    Screens.P1.dum.R.add(R);
                    Screens.GM.Selected = Screens.P1.dum.R.get(Screens.P1.dum.R.size()-1);
                    Screens.GM.label[3].add(Screens.GM.Selected);
                    Point P = new Point(this.getX()+this.getWidth(),this.getY());
                    P = CheckPoint(P,0);
                    Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                    Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                    Screens.GM.Selected= null;
                    Screens.GM.build(R);

                    revalidate();
           
                }
              
            
            super.paint(g);
            
        }
      
        
        
         public void setInfo()
    	{

    		this.Info = new JPanel();
    		this.Info.setLayout(new FlowLayout());
    		JPanel cont[]= new JPanel[2];
    		cont[0] = new JPanel(new FlowLayout());
    		cont[1] = new JPanel(new FlowLayout());
    		button[0] = new JButton("Create Marine");
    		button[1] = new JButton("Create Reaper");
    		label[0] = new JLabel(this.getTName());
    		label[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
    		label[2] = new JLabel();
                if(Team==ACC.P1.ChoosenColor)
    		label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5570_raceSc2_normal.png").getImage().getScaledInstance(50,50 ,1)));
    		
                if(Team==ACC.P2.ChoosenColor)
    		label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5570_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 ,1)));
    		
    		this.Info.add(cont[0]);
    		this.Info.add(cont[1]);
    		
    		cont[0].add(label[2]);
    		cont[0].add(label[0]);
    		cont[0].add(label[1]);
    		cont[1].add(button[0]);
    		cont[1].add(button[1]);
    		
            button[0].addActionListener(new Handler());
            button[1].addActionListener(new Handler());
   
    	}
        
        
	public Boolean CreateMarine(Player P) 
        {
            
           if(P.dum.M.size()==P.dum.MaxSmallUnits)
                return false;
            if (P.R.BuyTerran(50,0))
            {
               // P.dum.M.add(new Marine(P.ChoosenColor));
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;  
	}

	public Boolean CreateReaper(Player P)    
        {
              if(P.dum.R.size()==P.dum.MaxSmallUnits)
                return false;
            if (P.R.BuyTerran(100,50))
            {
                //P.dum.R.add(new Reaper(P.ChoosenColor));
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;  
        }
		private class Handler implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e) {
			
			Object buttonPressed = e.getSource();
			
			if(buttonPressed == button[0]){
                            //Check = true;
                            type = "Marine";
				if (Team==ACC.P1.ChoosenColor)
				CreateMarine(ACC.P1);
				if (Team==ACC.P2.ChoosenColor)
				CreateMarine(ACC.P2);
			}
			
			if(buttonPressed == button[1]){
                            //Check = true;
                            type = "Reaper";
				if (Team==ACC.P1.ChoosenColor)
					CreateReaper(ACC.P1);
					if (Team==ACC.P2.ChoosenColor)
					CreateReaper(ACC.P2);
			
			}
			
				
				
			
			
		}
                }
}