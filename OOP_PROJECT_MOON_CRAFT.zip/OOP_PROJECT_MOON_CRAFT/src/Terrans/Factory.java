package Terrans;
import GUI.Screens;
import User.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.*;
public class Factory extends Terran 
{
    private JLabel[] labels = new JLabel[3];
    private JButton [] Buttons = new JButton[2];
    private boolean Check = false;
    private String type ="";
    
    
    public Factory(Color c)  
    {   
        this.Team=c;
        this.setTName("Factory");
        this.setHealth(150);
        this.setMaxHealth(150);
        this.setMinerals(100);
        this.setGas(75);
        this.setInfo();
        this.setImage();
        this.alive=true;
    }
    
    public void paint(Graphics g)
        {
            if(Check && type.equals("Hellion"))
            {
                Check = false;
                Hellion H = new Hellion(Screens.P1.ChoosenColor);
                Screens.P1.dum.H.add(H);
                Screens.GM.Selected = Screens.P1.dum.H.get(Screens.P1.dum.H.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(H);
            
                revalidate();
           
            }
            
                if(Check && type.equals("SeigeTank"))
                {
                    Check = false;
                    SeigeTank S = new SeigeTank(Screens.P1.ChoosenColor);
                    Screens.P1.dum.ST.add(S);
                    Screens.GM.Selected = Screens.P1.dum.ST.get(Screens.P1.dum.ST.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                    Screens.GM.build(S);

                    revalidate();
           
                }
              
            
            super.paint(g);
            
        }
    
  public boolean setImage()
        {
            if(Team==ACC.P1.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\factory_render.png").getImage().getScaledInstance(125,125 ,1)));
            if(Team==ACC.P2.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\factory_render_2.png").getImage().getScaledInstance(125,125 ,1)));
            
            this.setSize(125, 125);
            return true;
        }
	public boolean CreateHellion(Player P)    
        {
              
             if(P.dum.H.size()==P.dum.MaxSmallUnits)
                return false;
            if (P.R.BuyTerran(100,0))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false;  
	}

	public boolean CreateSeigeTank(Player P)    
        {
           if(P.dum.ST.size()==P.dum.MaxSmallUnits)
                return false;
            if (P.R.BuyTerran(200,100))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false; 
	}

  
    public void setInfo() 
    {
        this.Info = new JPanel();
        this.Info.setLayout(new FlowLayout());
        JPanel[] cont = new JPanel[2];
        cont[0]=new JPanel (new FlowLayout());
        cont[1] = new JPanel (new FlowLayout());
        Buttons[0]=new JButton("Create Hellion");
        Buttons[1]=new JButton ("Create Seige Tank");
        cont[1].add(Buttons[0]);
        cont[1].add(Buttons[1]);
        labels[0] = new JLabel(this.getTName());
        labels[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
        labels[2] = new JLabel();
        labels[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\factory_render.png").getImage().getScaledInstance(50,50 ,1)));
    	cont[0].add(labels[2]);
        cont[0].add(labels[0]);
        cont[0].add(labels[1]);
        this.Info.add(cont[0]);
        this.Info.add(cont[1]);
        
        Buttons[0].addActionListener(new Handler());
        Buttons[1].addActionListener(new Handler());
        
        
    }
    
    public class Handler implements ActionListener
	{
		
            public void actionPerformed(ActionEvent e) {
			
		Object buttonPressed = e.getSource();
			
		if(buttonPressed == Buttons[0])
                {
                    type = "Hellion";
		  if (Team==ACC.P1.ChoosenColor)
		  CreateHellion(ACC.P1);
		  if (Team==ACC.P2.ChoosenColor)
		  CreateHellion(ACC.P2);
                }
			
		if(buttonPressed == Buttons[1])
                {
                    type = "SeigeTank";
		  if (Team==ACC.P1.ChoosenColor)
                  CreateSeigeTank(ACC.P1);
                  if (Team==ACC.P2.ChoosenColor)
        	  CreateSeigeTank(ACC.P2);
			
		}
			
				
				
			
			
		}
	}


}
