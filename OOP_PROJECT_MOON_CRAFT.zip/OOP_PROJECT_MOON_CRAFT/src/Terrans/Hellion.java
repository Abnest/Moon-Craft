package Terrans;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import EXceptions.*;
import GUI.Screens;



public class Hellion extends AMove implements IAttack {

	
	private MachineGun MG;
	private String speed;
	private JLabel[] label = new JLabel [3];
        private Thread  TAttack= new Thread(){
               public void run()
               {
                   while(TEnemy.getHealth()>0)
                   {
                       for (int i=0;i<MG.getRateOfFire();i++)
                       {
                           if (TEnemy.getHealth()<0)
                           {
                               TEnemy.setVisible(false);
                               
                           }
                           TEnemy.setHealth(TEnemy.getHealth()-MG.getDamagePower());
                           Screens.GM.repaint();
                            try {   
                                this.sleep(100*3);
                                } catch (InterruptedException ex) {
                                    System.err.println("Thread Interrupted "+TEnemy.getTName());
                                    return ; 
                                }
                       }
                     
                   }
                   TEnemy.alive=false;
                   TEnemy.setVisible(false);
               }
        };
       public boolean setImage()
        {
            if(Team==ACC.P1.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4393_raceSc2_normal.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
            if(Team==ACC.P2.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4393_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
            
            this.setSize(50, 50);
            return true;

        }
        
        public void setInfo()
      	{

      	this.Info = new JPanel();
      	this.Info.setLayout(new FlowLayout());
    		
      	label[0] = new JLabel(this.getTName());
      	label[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
      	label[2] = new JLabel();
        if(Team==ACC.P1.ChoosenColor)
        label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4393_raceSc2_normal.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
      	 if(Team==ACC.P2.ChoosenColor)
        label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4393_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
      	
        this.Info.add(label[2]);
    	this.Info.add(label[0]);
    	this.Info.add(label[1]);
      	}
        
        
        public Hellion(Color c)  
        {
            this.Team=c;
            this.MG=new MachineGun();
            this.setTName("Hellion");
            this.setHealth(100);
            this.setMaxHealth(100);
            this.setMinerals(100);
            this.setGas(0);
            this.setSpeed(5);
            this.setInfo();this.setImage();
            this.alive=true;
        }
    public void Attack(Terran T) 
        {
         this.TEnemy=T;
            if(!TAttack.isAlive())
            {
               TAttack= new Thread(){
               public void run()
               {
                   while(TEnemy.getHealth()>0)
                   {
                       for (int i=0;i<MG.getRateOfFire();i++)
                       {
                           if (TEnemy.getHealth()<0)
                           {
                               TEnemy.setVisible(false);
                               
                           }
                           TEnemy.setHealth(TEnemy.getHealth()-MG.getDamagePower());
                           Screens.GM.repaint();
                            try {   
                                this.sleep(100*3);
                                } catch (InterruptedException ex) {
                                    System.err.println("Thread Interrupted "+TEnemy.getTName());
                                    return ; 
                                }
                       }
                     
                   }
                   TEnemy.alive=false;
                   TEnemy.setVisible(false);
               }
        };
               TAttack.start();
            }   
            else 
            {
                TAttack.interrupt();
                TAttack= new Thread(){
               public void run()
               {
                   while(TEnemy.getHealth()>0)
                   {
                       for (int i=0;i<MG.getRateOfFire();i++)
                       {
                           if (TEnemy.getHealth()<0)
                           {
                               TEnemy.setVisible(false);
                               
                           }
                           TEnemy.setHealth(TEnemy.getHealth()-MG.getDamagePower());
                           Screens.GM.repaint();
                            try {   
                                this.sleep(100*3);
                                } catch (InterruptedException ex) {
                                    System.err.println("Thread Interrupted "+TEnemy.getTName());
                                    return ; 
                                }
                       }
                     
                   }
                   TEnemy.alive=false;
                   TEnemy.setVisible(false);
               }
        };
                TAttack.start();
            }
        }

}
