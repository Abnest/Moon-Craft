package Terrans;

import GUI.Screens;
import java.awt.*;
import java.io.Serializable;

public abstract class AMove extends Terran implements Serializable
{
        private String speed;
        private double speedx;
        private double speedy;
        public int D;
        public static final int WIDTH = 1920;
        public static final int HEIGHT = 1080;
        private static final int UPDATE_RATE = 100;
        public Thread createMT()
        {
            
            Thread TMove = new Thread()
            {
       
            public void run()
             {  D=getSize().width;
             Point t = nextPos;
                 while (Pos!=nextPos) 
                 {
                  speedx=1;
                  speedy=1;
                 if(Pos.x<nextPos.x)
                 {
                	 Pos.x+=speedx;
                 }
                 
                 else if(Pos.x>nextPos.x || Pos.x>WIDTH-D)
                 {   speedx=-speedx;
                 Pos.x+=speedx;
                 }
               
                 if(Pos.y<nextPos.y)
                 {
                	 Pos.y+=speedy;
                 }
                 
                 else if(Pos.y>nextPos.y || Pos.y>HEIGHT-D)
                 {   speedy=-speedy;
                 Pos.y+=speedy;
                 }
                 if (t != nextPos)
                     return;
                
                setBounds(Pos.x,Pos.y,D,D);
                
                  try {
                       Thread.sleep((100000 / (UPDATE_RATE*getSpeed())));  // milliseconds
                    } 
                  catch (InterruptedException ex) 
                    {   }
                    
                 }
             
                 }}; 
            return TMove;
        }
        
        public void setSpeed(Integer s) {
            
		speed = EDTerran.Encrypt(String.valueOf(s),1);
	}
            public Integer getSpeed() {
		return Integer.parseInt(EDTerran.Decrypt(speed, 1))*40;
	}   
        public boolean changePosition(Point PT)
        { 
            
            Thread TMove= createMT();
            this.nextPos=CheckPoint(PT, 0);
            if(!TMove.isAlive())
            TMove.start();
        
        return true;
        
        }
        public Point CheckPoint(Point P,int i){
        
            if(Screens.GM.label[3].getComponentAt(P)!=Screens.GM.label[3]){
                {
                    if (Team == Color.RED)
                    { if (i%2==0)
                        return CheckPoint( new Point(P.x,P.y+Screens.GM.label[3].getComponentAt(P).getSize().height),++i);
                        else 
                        return CheckPoint( new Point(P.x+Screens.GM.label[3].getComponentAt(P).getSize().width,P.y),++i);
                    }
                    else
                    {if (i%2==0)
                        return CheckPoint( new Point(P.x,P.y-Screens.GM.label[3].getComponentAt(P).getSize().height),++i);
                        else 
                        return CheckPoint( new Point(P.x-Screens.GM.label[3].getComponentAt(P).getSize().width,P.y),++i);
                    
                    
                    }
                }
            }
            else return P;

}

}
