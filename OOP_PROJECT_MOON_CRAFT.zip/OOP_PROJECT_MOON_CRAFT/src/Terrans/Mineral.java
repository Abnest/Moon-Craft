/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Terrans;

import GUI.Screens;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Mina
 */
public class Mineral extends JLabel{
    private int Capacity;
    private int sought=500;
    public void setImage()
    {
       this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\Mineral.png").getImage().getScaledInstance(50,50 , 1)));
       this.setSize(50, 50);
     }
    
    public Mineral(){
    
        this.Capacity = 2000;
        this.sought=25;    
    }
    
    public void setMCapacity(int C){
    
        this.Capacity = C;
    }
    
    
    public int getMCapacity(){
        return Capacity;
    
    }
        public int decMineral(){
        Capacity-=sought;
        return sought;
    
    }
    
       
    
    
}
