package Terrans;

public interface IWeapon {

	public boolean Fire();

}
