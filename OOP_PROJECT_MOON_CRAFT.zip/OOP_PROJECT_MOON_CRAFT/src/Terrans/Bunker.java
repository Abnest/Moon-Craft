package Terrans;

import java.awt.Color;
import java.awt.FlowLayout;
import java.util.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Bunker extends Terran {

	private String MaxCapacity;
        public ArrayList <IAttack> IA;
        private JLabel[] label = new JLabel [3];
        
        public boolean setImage()
        {
             if(Team==ACC.P1.ChoosenColor)
             this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5611_raceSc2_normal.png").getImage().getScaledInstance(125,125 ,1)));
                
             if(Team==ACC.P2.ChoosenColor)
             this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5611_raceSc2_normal_2.png").getImage().getScaledInstance(125,125 ,1)));
                
             this.setSize(125, 125);
            return true;
        }
        public Bunker(Color c)  
        {
        
        			
            this.Team=c;
            this.setMaxCapacity(5);
            this.setTName("Bunker");
            this.setHealth(200);
            this.setMaxHealth(200);
            this.setMinerals(75);
            this.setGas(0);
            this.setInfo();this.setImage();
            this.alive=true;
        }
        
       
        public void setInfo()
      	{

      	this.Info = new JPanel();
      	this.Info.setLayout(new FlowLayout());
    		
      	label[0] = new JLabel(this.getTName());
      	label[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
      	label[2] = new JLabel();
        if(Team==ACC.P1.ChoosenColor)
    	label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5611_raceSc2_normal.png").getImage().getScaledInstance(50,50 ,1)));
            
        if(Team==ACC.P2.ChoosenColor)
    	label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5611_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 ,1)));
           
        this.Info.add(label[2]);	
        this.Info.add(label[0]);	
        this.Info.add(label[1]);
      	}
        
        
	public boolean ReleaseAllAtoms() 
        {
            IA.clear();
            if(IA.isEmpty())
            {
                return true;
            }
            return false;
	}

	public boolean UploadAtom(Reaper R) {
		if(IA.size()==getMaxCapacity())
                    return false;
                else if (IA.size()<getMaxCapacity())
                    IA.add(R);
                    
                return true;
               
                
	}

        public boolean UploadAtom(Marine M)
        {
            if(IA.size()==getMaxCapacity())
                    return false;
            else if (IA.size()<getMaxCapacity())
                    IA.add(M);
                    
            return true;
                            
                
        }
        public Integer getMaxCapacity()
         {
		return Integer.parseInt(EDTerran.Decrypt(MaxCapacity, 1));
         }
        
	public void setMaxCapacity(Integer c) 
        {
            
		this.MaxCapacity = EDTerran.Encrypt(String.valueOf(c),1);
	}
}
