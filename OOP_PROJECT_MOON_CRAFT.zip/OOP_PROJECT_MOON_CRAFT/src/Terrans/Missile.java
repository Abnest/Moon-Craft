
package Terrans;
import Manage_files.*;
import java.awt.Image;
import java.awt.Point;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Missile extends JLabel implements IWeapon {

	private String DamagePower;
	public int RocketSpeedx;
        public int RocketSpeedy;
        int D;
        public Point Pos;
        public Point enemyPOS;
        public Point nextPos;
        public EncryptionDecryption EDMissile= new EncryptionDecryption(); 
       
        public Missile()
        {
            this.setDamagePower(75);
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\red-ball-hi.png").getImage().getScaledInstance(10,10 , Image.SCALE_DEFAULT)));
            this.setSize(10, 10);
        }
        public Integer getDamagePower() {
		return Integer.parseInt(EDMissile.Decrypt(DamagePower, 1));
	}
	public void setDamagePower(Integer D) {
            
		DamagePower = EDMissile.Encrypt(String.valueOf(D),1);
	}
        
    public boolean Fire() {
      return true; 
    }

}
