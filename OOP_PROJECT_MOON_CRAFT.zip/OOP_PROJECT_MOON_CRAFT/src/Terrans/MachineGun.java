package Terrans;
import Manage_files.*;


public class MachineGun implements IWeapon {

	private String DamagePower;
	private String RateOfFire;
        private EncryptionDecryption EDMachineGun= new EncryptionDecryption();
        MachineGun()
        {
            this.setDamagePower(5);
            this.setRateOfFire(5);
            
        }
	public boolean Fire()
	{
		return true;
	}
        public Integer getDamagePower() {
		return Integer.parseInt(EDMachineGun.Decrypt(DamagePower, 1));
	}
	public void setDamagePower(Integer D) {
            
		DamagePower = EDMachineGun.Encrypt(String.valueOf(D),1);
	}                
        public Integer getRateOfFire() {
		return Integer.parseInt(EDMachineGun.Decrypt(RateOfFire, 1));
	}
	public void setRateOfFire(Integer R) {
            
		RateOfFire = EDMachineGun.Encrypt(String.valueOf(R),1);
	}
        
       
}

