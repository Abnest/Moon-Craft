package Terrans;
import User.*;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.Screens;
import java.awt.*;



public class CommandCenter extends Terran {

	private JButton[] button = new JButton [1];	
	private JLabel[] label = new JLabel [3];
        private boolean Check = false;
       
    public CommandCenter(Color c) 
    {
            this.Team=c;
            this.setTName("CommandCenter");
            this.setHealth(300);
            this.setMaxHealth(300);
            this.setMinerals(400);
            this.setGas(150);
            
            this.setInfo();
            this.setImage();
            this.alive=true;
            
            
    }
     public boolean setImage()
        {
            if(Team==ACC.P1.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5568_raceSc2_normal.png").getImage().getScaledInstance(200,200 ,1)));
            if(Team==ACC.P2.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5568_raceSc2_normal_2.png").getImage().getScaledInstance(200,200 ,1)));
            this.setSize(200, 200);
            return true;
        }
      
      
      public void paint(Graphics g)
        {
            if(Check){
                Check = false;
                Builder B = new Builder(Screens.P1.ChoosenColor);
                Screens.P1.dum.BS.add(B);
                Screens.GM.Selected = Screens.P1.dum.BS.get(Screens.P1.dum.BS.size()-1);
                Screens.GM.label[3].add(Screens.GM.Selected);
                Point P = new Point(this.getX()+this.getWidth(),this.getY());
                P = CheckPoint(P,0);
                Screens.GM.Selected.setBounds(P.x,P.y,Screens.GM.Selected.getSize().width, Screens.GM.Selected.getSize().height);       
                Screens.GM.Selected.Pos = new Point (Screens.GM.Selected.getX(),Screens.GM.Selected.getY());
                Screens.GM.Selected= null;
                Screens.GM.build(B);
            
                revalidate();
           
            }
            
            super.paint(g);
            
        }
      
      public void setInfo()
    	{

    		this.Info = new JPanel();
    		this.Info.setLayout(new FlowLayout());
    		JPanel cont[]= new JPanel[2];
    		cont[0] = new JPanel(new FlowLayout());
    		cont[1] = new JPanel(new FlowLayout());
    		button[0] = new JButton("Create Builder");
    		label[0] = new JLabel(this.getTName());
    		label[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
    		label[2] = new JLabel();
                if(Team==ACC.P1.ChoosenColor)
                {
                    label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5568_raceSc2_normal.png").getImage().getScaledInstance(50,50 ,1)));
                }
                if(Team==ACC.P2.ChoosenColor)
                {
                    label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_5568_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 ,1)));
                }
                this.Info.add(cont[0]);
    		this.Info.add(cont[1]);
	  		
	  		cont[0].add(label[2]);
	  		cont[0].add(label[0]);
	  		cont[0].add(label[1]);
	  		cont[1].add(button[0]);
                        
	    		button[0].addActionListener(new Handler());
    	}
      
	public boolean CreateBuilder(Player P) 
        {
            if(P.dum.BS.size()==P.dum.MaxSmallUnits)
                return false;
            if (P.R.BuyTerran(50,0))
            {
                Screens.GM.label[0].setText("Minerals "+Screens.P1.R.getMinerals());
                Screens.GM.label[1].setText("Gas "+Screens.P1.R.getGas());
                repaint();
                Check = true;
                return true;
            }
            Check = false;
            return false; 
        }
	
	private class Handler implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e)
                {
			
			if(e.getSource() == button[0])
                        {    
                               
			if (Team==ACC.P1.ChoosenColor){
				CreateBuilder(ACC.P1);
                                
                                }
				if (Team==ACC.P2.ChoosenColor){
				CreateBuilder(ACC.P2);
                                }
			}
			
		}
	}

}