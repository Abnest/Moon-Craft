package Terrans;


public interface IAttack {
        
        
	public void Attack(Terran T);

}
