/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Terrans;

import javax.swing.*;

/**
 *
 * @author Mina
 */
public class Gas extends JLabel{
    
        private int Capacity;
        private int sought;

    public void setImage()
    {
       this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\Gas.png").getImage().getScaledInstance(50,50 , 1)));
       this.setSize(50, 50);
     }
    
    public Gas(){
    
        this.Capacity = 2000;
            this.sought=25;
    }
    
    public void setGCapacity(int G){
    
        this.Capacity = G;
    }
    
    
    public int getGCapacity(){
        return Capacity;
    
    }
    public int decGas(){
        Capacity-=sought;
        return sought;
    
    }
}
