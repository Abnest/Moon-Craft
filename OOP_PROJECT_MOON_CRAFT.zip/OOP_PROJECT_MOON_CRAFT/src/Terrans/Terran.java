package Terrans;
import Manage_files.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import GUI.Screens;
import java.io.Serializable;
public abstract class Terran extends JLabel {
       
	public Screens ACC = new Screens();
	private String TName;
	private String Health;
        private String MaxHealth;
        private String Minerals;
        private String Gas;
        public Color Team;
        public Point Pos;
        public JPanel Info;
        public boolean movable;
        public boolean attackable;
        public boolean alive;
        protected Point nextPos;
        protected Terran TEnemy;
        
        protected EncryptionDecryption EDTerran= new EncryptionDecryption(); 
        abstract public void setInfo();
        abstract public boolean setImage();
        public String getTName() {
		return EDTerran.Decrypt(TName,1);   
		
	}
	public boolean setTName(String name) {
		if(name.charAt(0)>='0' &&name.charAt(0)<='9')
			return false;
		this.TName= "";
		for(Integer i=0; i<name.length();i++)
			{
			
			if((name.charAt(i)>='a'&& name.charAt(i)<='z' )
				|| (name.charAt(i)>='A' && name.charAt(i)<='Z') 
				|| (name.charAt(i)>='0' &&name.charAt(i)<='9'))
			{
				this.TName+= name.charAt(i);
				
			}
			else return false;
			}
                this.TName=EDTerran.Encrypt(TName,1);
		return true;
	}
	public Integer getHealth() {
		return Integer.parseInt(EDTerran.Decrypt(Health, 1));
	}
	public synchronized void setHealth(Integer health) {
                if(health<0)
                    Health =  EDTerran.Encrypt(String.valueOf(0),1);
                else Health =  EDTerran.Encrypt(String.valueOf(health),1);
	}
        
        public Integer getMaxHealth() {
		return Integer.parseInt(EDTerran.Decrypt(MaxHealth, 1));
	}
	public void setMaxHealth(Integer maxhealth) {
            
		MaxHealth = EDTerran.Encrypt(String.valueOf(maxhealth),1);
	}
        
	public int getMinerals() {
		return Integer.parseInt(EDTerran.Decrypt(Minerals, 1));
	}

	public void setMinerals(int m) {
		this.Minerals = EDTerran.Encrypt(String.valueOf(m),1);
	}

	public int getGas() {
		return Integer.parseInt(EDTerran.Decrypt(Gas, 1));
	}

	public void setGas(int g) {
		this.Gas = EDTerran.Encrypt(String.valueOf(g),1);
	}

           public Point CheckPoint(Point P,int i){
        
            if(Screens.GM.label[3].getComponentAt(P)!=Screens.GM.label[3]){
                {
                    if (Team == Color.RED)
                    { if (i%2==0)
                        return CheckPoint( new Point(P.x,P.y+Screens.GM.label[3].getComponentAt(P).getSize().height),++i);
                        else 
                        return CheckPoint( new Point(P.x+Screens.GM.label[3].getComponentAt(P).getSize().width,P.y),++i);
                    }
                    else
                    {if (i%2==0)
                        return CheckPoint( new Point(P.x,P.y-Screens.GM.label[3].getComponentAt(P).getSize().height),++i);
                        else 
                        return CheckPoint( new Point(P.x-Screens.GM.label[3].getComponentAt(P).getSize().width,P.y),++i);
                    
                    
                    }
                }
            }
            else return P;

}

}

