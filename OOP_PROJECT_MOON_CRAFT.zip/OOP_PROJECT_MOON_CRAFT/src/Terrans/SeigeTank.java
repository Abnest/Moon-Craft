package Terrans;
import GUI.Screens;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class SeigeTank extends AMove implements  IAttack {

	private String speed;
	private Missile M;
	private JLabel[] label = new JLabel [3];
       
public synchronized void firefire(Thread TAttack) 
{
            M.nextPos = new Point(TEnemy.Pos.x+(TEnemy.getWidth()/2),TEnemy.Pos.y+(TEnemy.getHeight()/2));
            M.D=M.getSize().width;

   while (!(M.Pos.x==M.nextPos.x&&M.Pos.y==M.nextPos.y)) 
   {
                M.RocketSpeedx = 1;
                M.RocketSpeedy = 1;
                 
                 if(M.Pos.x<M.nextPos.x)
                 {
                	 M.Pos.x+=M.RocketSpeedx;
                 }
                 
                 else if(M.Pos.x>M.nextPos.x)
                 {   M.RocketSpeedx=-M.RocketSpeedx;
                 M.Pos.x+=M.RocketSpeedx;
                 }
               
                 if(M.Pos.y<M.nextPos.y)
                 {
                	 M.Pos.y+=M.RocketSpeedy;
                 }
                 
                 else if(M.Pos.y>M.nextPos.y)
                 {   
                     M.RocketSpeedy=-M.RocketSpeedy;
                    M.Pos.y+=M.RocketSpeedy;
                 }

                M.setBounds(M.Pos.x,M.Pos.y,M.D,M.D);
                try {
                    TAttack.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(SeigeTank.class.getName()).log(Level.SEVERE, null, ex);
                }
                    
            }
        }
          public boolean setImage()
        {
            if(Team==ACC.P1.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4394_raceSc2_normal.png").getImage().getScaledInstance(75,75 , Image.SCALE_DEFAULT)));
            if(Team==ACC.P2.ChoosenColor)
            this.setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4394_raceSc2_normal_2.png").getImage().getScaledInstance(75,75 , Image.SCALE_DEFAULT)));
            
            this.setSize(75, 75);
            return true;
        }
        public SeigeTank(Color c)
        {
            this.Team=c;
            M= new Missile();
            this.setTName("SeigeTank");
            this.setHealth(150);
            this.setMaxHealth(150);
            this.setMinerals(200);
            this.setGas(100);
            this.setSpeed(1);
            this.setInfo();
            this.setImage();
            this.alive=true;
        }	
        
       public void setInfo()
      	{

      	this.Info = new JPanel();
      	this.Info.setLayout(new FlowLayout());
    		
      	label[0] = new JLabel(this.getTName());
      	label[1] = new JLabel(this.getHealth()+"/"+ this.getMaxHealth());
      	label[2] = new JLabel();
        if(Team==ACC.P1.ChoosenColor)
        label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4394_raceSc2_normal.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
    	if(Team==ACC.P2.ChoosenColor)
        label[2].setIcon(new ImageIcon(new ImageIcon("Images\\Renders\\thumb_4394_raceSc2_normal_2.png").getImage().getScaledInstance(50,50 , Image.SCALE_DEFAULT)));
    		
      	this.Info.add(label[2]);
    	this.Info.add(label[0]);
    	this.Info.add(label[1]);
      	}
      
        
        
	public void Attack(Terran T) 
        {
         this.TEnemy=T;
      
           Thread TAttack= new Thread() {
               public void run()
               {   
                   Terran t = TEnemy;
                   
                   Screens.GM.label[3].add(M);
                   M.setBounds(Pos.x+(getWidth()/2),Pos.y+(getHeight()/2),10,10);
                   Screens.GM.repaint();
                   while(TEnemy.getHealth()>0)
                   {
                       if (t != TEnemy)
                           return;
                       M.Pos= new Point(Pos);
                       firefire(this);
                       TEnemy.setHealth(TEnemy.getHealth()-M.getDamagePower());
                       Screens.GM.repaint();

                       M.setBounds(Pos.x+(getWidth()/2),Pos.y+(getHeight()/2),10,10);
                   }
                   TEnemy.setVisible(false);
                   TEnemy.alive = false;
               }
        }; 
            TAttack.start();
    
        }
	
}
