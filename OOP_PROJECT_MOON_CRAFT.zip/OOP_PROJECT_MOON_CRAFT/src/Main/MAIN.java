
package Main;
import GUI.*;
import User.countDead;
import java.io.IOException;
public class MAIN 
{
	
    public static void main(String[] args) throws IOException 
    { 
        
    	Screens.setGUI();
    	Screens.Ln.setVisible(true);
    	
        countDead CD= new countDead();
        CD.CalculatingKills();
    	
    }
}