/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EXceptions;
import Terrans.*;
/**
 *
 * @author Youssef-Abnest
 */
public class CannotAttackException extends Exception {
    public  CannotAttackException()
    {   
        super();  
    }

    public boolean check(Terran Attacking,Terran Attacked)
    {
        return(Attacking.Team.equals(Attacked.Team));
    }
}
