/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Network;

import GUI.Screens;
import User.Player;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Youssef-Abnest
 */
public class Server implements Runnable{
    private ServerSocket Mysocket;
    private Socket clientsocket;
    private ArrayList<Socket> Allconnections=new ArrayList<Socket>();
    public Server() throws IOException
    {
        Mysocket = new ServerSocket(7000);
    }


    public void Awaits() {
    
        try {
            clientsocket=Mysocket.accept();
            Allconnections.add(clientsocket);
            ConnectionThread ct=new ConnectionThread(clientsocket);
            Thread t1=new Thread(ct);
            t1.start();
            Thread.sleep(1000);
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

    @Override
    public void run() {
        try {
            clientsocket=Mysocket.accept();
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
          while(true)
          {
                try {
                   
                    Allconnections.add(clientsocket);
                   for (Socket s: Allconnections)
                     {
                    ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream()) ;
                    Player p = Screens.P1;
                    oos.writeObject(Screens.GM.label[3]);
                    Thread.sleep(1000);
                     }
                } catch (IOException | InterruptedException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }
          }
    }
}
