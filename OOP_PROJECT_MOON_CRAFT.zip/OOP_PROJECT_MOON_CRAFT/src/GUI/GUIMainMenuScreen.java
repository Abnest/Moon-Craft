package GUI;
import javax.swing.*;

import User.Player;
import Manage_files.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
public class GUIMainMenuScreen extends JWindow 
{
	private static Screens Scc = new Screens();
  	public ManageSaveAndLoad MSL = new ManageSaveAndLoad();
	 private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
	 public double x =size.getWidth();
	 public double y =size.getHeight();
	 private Color c;
    private JButton buttons[]=new JButton[5];
    private JLabel title = new JLabel("Main Menu");
    private JLabel label = new JLabel(" ");
    private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    private myGridBagConstraints GBC= new myGridBagConstraints();
    private Font f;
    private ImageIcon icon;
    private Container cp;
    public GUIMainMenuScreen() throws IOException
    {
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
    	setSize((int)x,(int)y);
        icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
        JLabel picture = new JLabel(icon);
        setContentPane(picture);
        f = new Font("Forte",1,30);
        cp = getContentPane();
        cp.setLayout(new GridBagLayout());
        GBC.addGBC(0, 0, -1, -1, -1, -1, 2, " ");
        title.setForeground(Color.white);
        title.setFont(f);
        title.setBackground(Color.WHITE);
        cp.add(title,GBC);
        GBC.addGBC(0, 1, -1, -1, -1, -1, 2, " ");
        cp.add(label,GBC);
        f=new Font("Forte",0,20);
        buttons[0]=new JButton("New Game");
        GBC.addGBC(0, 2, -1, -1, -1, -1, 2, " ");
        buttons[0].setFont(f);
        cp.add(buttons[0],GBC);
        GBC.addGBC(0, 3, -1, -1, -1, -1, 2, " ");
        buttons[1]=new JButton("Load Game");
        buttons[1].setFont(f);
        cp.add(buttons[1],GBC);
        GBC.addGBC(0, 4, -1, -1, -1, -1, 2, " ");
        buttons[2]=new JButton("Options");
        buttons[2].setFont(f);
        cp.add(buttons[2],GBC);
        GBC.addGBC(0, 5, -1, -1, -1, -1, 2, " ");
        buttons[3]=new JButton("Credits");
        buttons[3].setFont(f);
        cp.add(buttons[3],GBC);
        GBC.addGBC(0, 6, -1, -1, -1, -1, 2, " ");
        buttons[4]=new JButton("Quit");
        buttons[4].setFont(f);
        cp.add(buttons[4],GBC);
        
        this.buttons[0].addActionListener(new Handler());
        this.buttons[1].addActionListener(new Handler());
        this.buttons[2].addActionListener(new Handler());
        this.buttons[3].addActionListener(new Handler());
        this.buttons[4].addActionListener(new Handler());
    }
   
    private class Handler implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e) 
		{
			
			Object buttonPressed = e.getSource();
			
			
			if(buttonPressed == buttons[0])
			{
				Scc.GM.setVisible(true);
				setVisible(false);
				dispose();			
			}
			
			if(buttonPressed == buttons[1])
			{
				if (c==Scc.P1.ChoosenColor)
					try {
						MSL.LoadData(Scc.P1.A.getUserName());
					} catch (ClassNotFoundException | IOException e2) {
						e2.printStackTrace();
					}
					if (c==Scc.P2.ChoosenColor)
						try {
							MSL.LoadData(Scc.P2.A.getUserName());
						} catch (ClassNotFoundException | IOException e1) {
							e1.printStackTrace();
						}
			}
			
			if(buttonPressed == buttons[2])
			{
				Scc.Op.setVisible(true);
				setVisible(false);
				dispose();
			}
			
			if(buttonPressed == buttons[3])
			{
				Scc.GC.setVisible(true);
				
				setVisible(false);
				dispose();
			}	
		
			if(buttonPressed == buttons[4])
			{
				setVisible(false);

				dispose();
			}	
				
			
			
		}
	}
    
}
