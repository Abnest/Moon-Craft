package GUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.imageio.ImageIO;

public class GUIControls extends JWindow
{
	private static Screens Scc = new Screens();
    private JLabel labels[]= new JLabel[7];
    private JButton button = new JButton();
    private ImageIcon icon;
    private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    private Font f;
    private Container cp;
    private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
    public double x =size.getWidth();
    public double y =size.getHeight();
    private GUI.myGridBagConstraints GBC = new GUI.myGridBagConstraints();
    
    public GUIControls() throws IOException
    {
        setSize((int)x,(int)y);
        setLocation(0, 0);
        icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
        JLabel picture = new JLabel(icon);
        setContentPane(picture);
        f = new Font("Forte",1,30);
        cp = getContentPane();
        cp.setLayout(new GridBagLayout());
        
        button = new JButton("Main Menu");
        labels[0] = new JLabel ("Right Click: ");
        labels[1]= new JLabel("To move or attack  ");
        labels[2]= new JLabel("Left Click:  ");
        labels[3]= new JLabel("To select one unit  ");
        labels[4]= new JLabel("Hold left mouse button and move:  ");
        labels[5]= new JLabel("To select more than one unit  ");
        labels[6]=new JLabel("Controls ");
        
        GBC.addGBC(0, 0, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[6],GBC);
        labels[6].setFont(f);
        labels[6].setForeground(Color.ORANGE);
        
        GBC.addGBC(0, 1, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[0],GBC);
        labels[0].setFont(f);
        labels[0].setForeground(Color.BLACK);
        
        GBC.addGBC(1, 1, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[1],GBC);
        labels[1].setFont(f);
        labels[1].setForeground(Color.WHITE);
        
        GBC.addGBC(0, 2, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[2],GBC);
        labels[2].setFont(f);
        labels[2].setForeground(Color.BLACK);
        
        GBC.addGBC(1, 2, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[3],GBC);
        labels[3].setFont(f);
        labels[3].setForeground(Color.WHITE);
        
        GBC.addGBC(0, 3, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[4],GBC);
        labels[4].setFont(f);
        labels[4].setForeground(Color.BLACK);
        
        GBC.addGBC(1, 3, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[5],GBC);
        labels[5].setFont(f);
        labels[5].setForeground(Color.WHITE);
        
        GBC.addGBC(1, 4, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(button,GBC);
        button.setFont(f);
        
        button.addActionListener(new Handler());
        
    }
    
    private class Handler implements ActionListener
  	{
  		
  		public void actionPerformed(ActionEvent e) 
  		{
  			
  			Object buttonPressed = e.getSource();
  			
  			
  			if(buttonPressed == button)
  			{
  				
  					Scc.Mm.setVisible(true);
  					setVisible(false);
  					dispose();
  					
  					
  			}
  			
  				
  			
  			
  		}
     
  	}
    
}
