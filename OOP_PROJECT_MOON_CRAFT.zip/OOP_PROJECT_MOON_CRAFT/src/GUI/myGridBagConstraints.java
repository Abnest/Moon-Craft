/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.GridBagConstraints;

/**
 *
 * @author Youssef-Abnest
 */
public class myGridBagConstraints extends GridBagConstraints {
     public void addGBC (int gx,int gy,int ix,int iy,int gw,int gh,int check,String pos){
		if (gx!=-1)
		gridx = gx;
		if (gy!=-1)
                gridy = gy;
		if (ix!=-1)
                ipadx = ix;
		if (iy!=-1)
                ipady = iy;
		if (gw!=-1)
                gridwidth = gw;
		if (gh!=-1)
                gridheight = gh;
		
		if(pos.equals("Right"))
		anchor = GridBagConstraints.EAST;
		else if(pos.equals("Left"))
			anchor = GridBagConstraints.WEST;
		else if(pos.equals("Middle"))
			anchor = GridBagConstraints.CENTER;

		
    }
}
