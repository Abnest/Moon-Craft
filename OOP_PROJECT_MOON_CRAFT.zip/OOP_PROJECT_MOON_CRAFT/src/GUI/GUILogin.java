package GUI;
import User.Account;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;

public class GUILogin extends JFrame{

	private static Screens Scc = new Screens();
	private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
	public double x =size.getWidth();
	public double y =size.getHeight();
	private JButton[] button = new JButton [3];
	private JLabel[] label = new JLabel [2];
	private JTextField[] tField = new JTextField [1];
	private JPasswordField[] pField = new JPasswordField [1];
	private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        private myGridBagConstraints GBC = new myGridBagConstraints();
        private ImageIcon icon ;
        private Font f;
        private Container cont;
	public GUILogin() throws IOException{
		
		/*setExtendedState(JFrame.MAXIMIZED_BOTH);*/
		setSize((int)x,(int)y);
		button[0] = new JButton("Create New Account");
		button[1] = new JButton("LogIn");
		button[2] = new JButton("Quit");
		

		label[0] = new JLabel("UserName");
		label[1] = new JLabel("Password");
		
		tField[0] = new JTextField(20);
		pField[0] = new JPasswordField(20);
                icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
                JLabel picture = new JLabel(icon);
                setContentPane(picture);
               
		cont = this.getContentPane();
                 this.cont.setLayout(new GridBagLayout());
                f= new Font("Forte",1,25);
		GBC.addGBC( 0,1,1,1,2,1,GridBagConstraints.CENTER,"Middle");
                label[0].setFont(f);
                cont.add(label[0],GBC);
		GBC.addGBC( 2,1,1,1,2,1,GridBagConstraints.CENTER,"Middle");
                cont.add(tField[0],GBC);
		GBC.addGBC( 0,2,1,1,2,1,GridBagConstraints.CENTER,"Middle");
                cont.add(label[1],GBC);
		label[1].setFont(f);
                GBC.addGBC( 2,2,1,1,2,1,GridBagConstraints.CENTER,"Middle");
                cont.add(pField[0],GBC);
		GBC.addGBC( 0,3,1,1,2,1,GridBagConstraints.CENTER,"Middle");
                button[0].setFont(f);
                cont.add(button[0],GBC);
		GBC.addGBC( 2,3,10,10,2,1,GridBagConstraints.CENTER,"Middle");
                cont.add(button[1],GBC);
		button[1].setFont(f);
                GBC.addGBC( 2,4,1,1,2,1,GridBagConstraints.CENTER,"Middle");
                cont.add(button[2],GBC);
		button[2].setFont(f);
		
		this.button[0].addActionListener(new Handler());
		this.button[1].addActionListener(new Handler());
		this.button[2].addActionListener(new Handler());
	}
        
private class Handler implements ActionListener
{
		
    public void actionPerformed(ActionEvent e) 
    {
			
	Object buttonPressed = e.getSource();
        Account one= new Account();
                        
	if(buttonPressed == button[0])
	{
				
            Scc.CA.setVisible(true);
            setVisible(false);
            dispose();

	}
			
	if(buttonPressed == button[1])
	{
            if(tField[0].getText().equals("")||pField[0].getText().equals(""))
            {
                JOptionPane.showMessageDialog(null, "Inavild username or password, try again","Alert",JOptionPane.ERROR_MESSAGE);
                one.setPassword(pField[0].getText());
                one.setUserName(tField[0].getText());
            }
            else
            {
                one.setPassword(pField[0].getText());
                one.setUserName(tField[0].getText());
            }
                            
            try 
            {
                if(Screens.AFM.CheckOccuranceAccount(one)==true)
                {
                    Scc.P1.A = one;
                    Scc.Mm.setVisible(true);
                    setVisible(false);
                    dispose();
                }
                else 
                {
                    JOptionPane.showMessageDialog(null, "Inavild username or password, try again","Alert",JOptionPane.ERROR_MESSAGE);
                    tField[0].setText("");
                    pField[0].setText("");
                    
                }
            } 
            catch (ClassNotFoundException ex) 
            {
               Logger.getLogger(GUILogin.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (IOException ex) 
            {
                JOptionPane.showMessageDialog(null, "Account does not exist","Alert",JOptionPane.ERROR_MESSAGE);
            }
				
	}
			
	if(buttonPressed == button[2])
	{
            Scc.Mm.setVisible(false);
	    Scc.Mm.dispose();
				
	    setVisible(false);
	    dispose();
	}		
	}
    }
	
}
