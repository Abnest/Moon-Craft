package GUI;
import Manage_files.ManageSaveAndLoad;
import java.awt.*;
import javax.swing.*;
/*
import Manage_files.ManageSaveAndLoad;
*/
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GUIMapMenu extends JWindow {

    private static Screens Scc = new Screens();
	//public ManageSaveAndLoad MSL = new ManageSaveAndLoad();
    private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
    public double x =size.getWidth();
    public double y =size.getHeight();
    private JButton buttons[]=new JButton[6];
    private JLabel title = new JLabel("Pause");
    private JLabel label = new JLabel(" ");
    private Color c;
   // private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    private myGridBagConstraints GBC= new myGridBagConstraints();
    private Font f;
    private Container cp;

    
    public GUIMapMenu() throws IOException
    {
        setSize((int)x,(int)y);
        setLocation(0, 0);
        this.setBackground(new Color(0,0,0,0.5f));
        f = new Font("Forte",1,30);
        cp = getContentPane();
        cp.setLayout(new GridBagLayout());
        GBC.addGBC(0, 0, -1, -1, -1, -1, 2, " ");
        title.setForeground(Color.black);
        title.setFont(f);
        title.setBackground(Color.BLACK);
        cp.add(title,GBC);
        GBC.addGBC(0, 1, -1, -1, -1, -1, 2, " ");
        cp.add(label,GBC);
        f=new Font("Forte",0,20);
        buttons[0]=new JButton("Resume");
        GBC.addGBC(0, 2, -1, -1, -1, -1, 2, " ");
        buttons[0].setFont(f);
        cp.add(buttons[0],GBC);
        GBC.addGBC(0, 3, -1, -1, -1, -1, 2, " ");
        buttons[1]=new JButton("Save Game");
        buttons[1].setFont(f);
        cp.add(buttons[1],GBC);
        GBC.addGBC(0, 4, -1, -1, -1, -1, 2, " ");
        buttons[2]=new JButton("Load Game");
        buttons[2].setFont(f);
        cp.add(buttons[2],GBC);
        GBC.addGBC(0, 5, -1, -1, -1, -1, 2, " ");
        buttons[3]=new JButton("Main Menu");
        buttons[3].setFont(f);
        cp.add(buttons[3],GBC);
        GBC.addGBC(0, 7, -1, -1, -1, -1, 2, " ");
        buttons[4]=new JButton("Quit");
        buttons[4].setFont(f);
        cp.add(buttons[4],GBC);
        
        GBC.addGBC(0, 6, -1, -1, -1, -1, 2, " ");
        buttons[5]=new JButton("Statistics");
        buttons[5].setFont(f);
        cp.add(buttons[5],GBC);
        
       /* title.setOpaque(false);
        buttons[0].setBackground(new Color(0,0,0,0));
        buttons[1].setOpaque(false);
        buttons[2].setOpaque(false);
        buttons[3].setOpaque(false);
        buttons[4].setOpaque(false);
        */
        this.buttons[0].addActionListener(new Handler());
        this.buttons[1].addActionListener(new Handler());
        this.buttons[2].addActionListener(new Handler());
        this.buttons[3].addActionListener(new Handler());
        this.buttons[4].addActionListener(new Handler());
        this.buttons[5].addActionListener(new Handler());
    }
   
    private class Handler implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e) 
		{
			
			Object buttonPressed = e.getSource();
			
			ManageSaveAndLoad MSL = new ManageSaveAndLoad();
			if(buttonPressed == buttons[0])
			{
				Scc.GM.setVisible(true);
				setVisible(false);
				dispose();			
			}
			
			if(buttonPressed == buttons[1])
			MSL.SaveData(Scc.P1);

			
			
			if(buttonPressed == buttons[2]){
			try {
                            MSL.LoadData(Scc.P1.A.getUserName());
                        } catch (IOException ex) {
                            Logger.getLogger(GUIMapMenu.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(GUIMapMenu.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        }
			if(buttonPressed == buttons[3])
			{
				Scc.Mm.setVisible(true);
				
				Scc.GM.setVisible(false);
				Scc.GM.dispose();
				setVisible(false);
				dispose();
			}	
		
			if(buttonPressed == buttons[4])
			{
				int selectedOption = JOptionPane.showConfirmDialog(null, "Are you sure want to Close without Saving?", "Confirm", JOptionPane.YES_NO_OPTION);
                                if(selectedOption==JOptionPane.NO_OPTION)
                                {
                                    Scc.GM.setVisible(true);
                                    setVisible(false);
                                    dispose();
                                }
                                else if(selectedOption==JOptionPane.YES_OPTION)
                                {
                                    Scc.GM.setVisible(false);
                                    Scc.GM.dispose();
                                    System.exit(0);
                                    setVisible(false);
                                    dispose();
                                }
			}	
                        if(buttonPressed == buttons[5])
			{
                            Scc.St.setVisible(true);
                            Scc.St.updateStat();
                            
                            setVisible(false);
                            dispose();
			}
				
			
			
		}
	}
}
