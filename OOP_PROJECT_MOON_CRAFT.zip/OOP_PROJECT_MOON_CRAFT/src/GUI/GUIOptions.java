package GUI;
import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class GUIOptions extends JWindow
{
    private static Screens Scc = new Screens();
    private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
    public double x =size.getWidth();
    public double y =size.getHeight();
    private JButton[] button = new JButton [3];
    private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    private Font f;
    private ImageIcon icon;
    private Container cp;
    private GUI.myGridBagConstraints GBC = new GUI.myGridBagConstraints();
    public GUIOptions() throws IOException
    {
        setSize((int)x,(int)y);
        setLocation(0, 0);
        icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
        JLabel picture = new JLabel(icon);
        setContentPane(picture);
        f = new Font("Forte",1,30);
        cp = getContentPane();
        cp.setLayout(new GridBagLayout());
        
        button[0]=new JButton("Help");
        GBC.addGBC(0, 0, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(button[0],GBC);
        button[0].setFont(f);
        button[1]=new JButton("Controls");
        GBC.addGBC(0, 1, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(button[1],GBC);
        button[1].setFont(f);
        button[2]=new JButton("Main Menu");
        GBC.addGBC(0, 2, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(button[2],GBC);
        button[2].setFont(f);
        
        this.button[0].addActionListener(new Handler());
        this.button[1].addActionListener(new Handler());
        this.button[2].addActionListener(new Handler());
    }
    
    private class Handler implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e) 
		{
			
			Object buttonPressed = e.getSource();
			
			
			if(buttonPressed == button[0])
			{
				Scc.In.setVisible(true);
			
			}
			

			if(buttonPressed == button[1])
			{
				Scc.Co.setVisible(true);
				
				setVisible(false);
				dispose();
			}
			
			if(buttonPressed == button[2])
			{
				Scc.Mm.setVisible(true);
				
				setVisible(false);
				dispose();
			}
        }
   }
 
}
