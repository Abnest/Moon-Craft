package GUI;

import Manage_files.AccountFileManage;
import User.Player;
import java.awt.Color;
import java.io.IOException;

public class Screens{

	public static GUIMap GM; 
	public static GUICreateNewAccount CA ;
	public static GUIInfo In;
	public static GUILogin Ln;
	public static GUIMainMenuScreen Mm;
	public static GUIMapMenu MpM;
	public static GUICredits GC;
	public static GUIOptions Op;
	public static GUIControls Co;
        public static GUIStatistics St;
	public static AccountFileManage AFM;
        public static Player P1 = new Player();
        public static Player P2 = new Player();
        public Screens()
        {
            P1.ChoosenColor=Color.RED;
            P2.ChoosenColor=Color.BLUE;
        }
	public static void setGUI(){
		try {
                        GM = new GUIMap();
			CA = new GUICreateNewAccount();
			In = new GUIInfo();
			Ln = new GUILogin();
			Mm = new GUIMainMenuScreen();
			MpM = new GUIMapMenu();
			GC = new GUICredits();
			Op = new GUIOptions();
			Co = new GUIControls();
                        AFM = new AccountFileManage();
                        St = new GUIStatistics();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
