/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import javax.swing.JPanel;
import GUI.Screens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JWindow;
/**
 *
 * @author Bringyyy
 */
public class GUIStatistics extends JWindow{

   private JLabel labels[]= new JLabel[5];
   	 private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
	 public double x =size.getWidth();
	 public double y =size.getHeight();
         private JButton back= new JButton("Back");
   private ImageIcon icon;
   private static Screens Scc = new Screens();
   private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
   private Font f;
   private GUI.myGridBagConstraints GBC = new GUI.myGridBagConstraints();
   
   public GUIStatistics()
   {
       setSize((int)x,(int)y);
       try {
           icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
       } catch (IOException ex) {
           Logger.getLogger(GUIStatistics.class.getName()).log(Level.SEVERE, null, ex);
       }
        JLabel picture = new JLabel(icon);
        setContentPane(picture);
        
        f = new Font("Forte",1,30);
        
       
       labels[0] = new JLabel("Statistics");
       labels[1] = new JLabel("Number of Your Kills:"+Screens.P1.kills);
       labels[2] = new JLabel("Gases used/Gases gained:"+Screens.P1.R.getGas()+" / "+Screens.P1.R.getabsGas());
       labels[3] = new JLabel("Minerals used/Minerals gained:"+Screens.P1.R.getMinerals()+" / "+Screens.P1.R.getabsMinerals());

       
       this.setLayout(new GridBagLayout());
        
        GBC.addGBC(0, 0, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[0].setForeground(Color.BLACK);
        this.add(labels[0],GBC);
        labels[0].setFont(f);
        
        GBC.addGBC(0, 1, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[1].setForeground(Color.BLACK);
        this.add(labels[1],GBC);
        labels[1].setFont(f);
        
        GBC.addGBC(0, 2, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[2].setForeground(Color.BLACK);
        this.add(labels[2],GBC);
        labels[2].setFont(f);
        
        GBC.addGBC(0, 3, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[3].setForeground(Color.BLACK);
        this.add(labels[3],GBC);
        labels[3].setFont(f);
        
        GBC.addGBC(0, 4, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        back.setForeground(Color.BLACK);
        this.add(back,GBC);
        back.setFont(f);
        
        back.addActionListener(new Handler());

   }
    	private class Handler implements ActionListener
 	{
 		
 		public void actionPerformed(ActionEvent e) 
 		{
 			
 			Object buttonPressed = e.getSource();
 			
 			
 			if(buttonPressed == back)
 			{
 				
 					Scc.Mm.setVisible(true);
 					setVisible(false);
 					dispose();
 					
 					
 			}
 		
 			
 		}
 	}
   public void updateStat()
   {
       labels[1].setText("Number of Your Kills:"+Screens.P1.kills);
       labels[2].setText("Gases used/Gases gained:"+Screens.P1.R.getGas()+" / "+Screens.P1.R.getabsGas());
       labels[3].setText("Minerals used/Minerals gained:"+Screens.P1.R.getMinerals()+" / "+Screens.P1.R.getabsMinerals());

   }
}
