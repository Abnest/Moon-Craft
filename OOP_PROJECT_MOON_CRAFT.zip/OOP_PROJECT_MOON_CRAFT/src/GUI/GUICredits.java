package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class GUICredits extends JWindow
{	 
	 private static Screens Scc = new Screens();
	 private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
	 public double x =size.getWidth();
	 public double y =size.getHeight();
     private JLabel labels[]= new JLabel[5];
     private JButton MainButton = new JButton();
     private ImageIcon icon;
     private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
     private JPanel cp = new JPanel();
     private GUI.myGridBagConstraints GBC = new GUI.myGridBagConstraints();
     private Font f;
     public GUICredits() throws IOException
     {
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
    	 setSize((int)x,(int)y);
        icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
        JLabel picture = new JLabel(icon);
        setContentPane(picture);
        
        f = new Font("Forte",1,30);
        
        labels[0]=new JLabel("Created By: ");
        labels[1]=new JLabel("Mareine Nassif");
        labels[2]=new JLabel("Mina Samir ");
        labels[3]=new JLabel("Nardeen Nabil ");
        labels[4]=new JLabel("Youssef Samy ");
        
        MainButton = new JButton("Main Menu");
        
        this.setLayout(new GridBagLayout());
        
        GBC.addGBC(0, 0, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[0].setForeground(Color.ORANGE);
        this.add(labels[0],GBC);
        labels[0].setFont(f);
        
        GBC.addGBC(0, 1, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[1].setForeground(Color.BLACK);
        this.add(labels[1],GBC);
        labels[1].setFont(f);
        
        GBC.addGBC(0, 2, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[2].setForeground(Color.BLACK);
        this.add(labels[2],GBC);
        labels[2].setFont(f);
        
        GBC.addGBC(0, 3, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[3].setForeground(Color.BLACK);
        this.add(labels[3],GBC);
        labels[3].setFont(f);
        
        GBC.addGBC(0, 4, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[4].setForeground(Color.BLACK);
        this.add(labels[4],GBC);
        labels[4].setFont(f);
        
        GBC.addGBC(0, 5, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        MainButton.setForeground(Color.BLACK);
        this.add(MainButton,GBC);
        MainButton.setFont(f);
        
        this.MainButton.addActionListener(new Handler());
     }
     
 	private class Handler implements ActionListener
 	{
 		
 		public void actionPerformed(ActionEvent e) 
 		{
 			
 			Object buttonPressed = e.getSource();
 			
 			
 			if(buttonPressed == MainButton)
 			{
 				
 					Scc.Mm.setVisible(true);
 					setVisible(false);
 					dispose();
 					
 					
 			}
 		
 			
 		}
 	}
}
