package GUI;
import Manage_files.AccountFileManage;
import User.Account;
import javax.swing.*;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class GUICreateNewAccount extends JFrame
{
    private static Screens Scc = new Screens();
    private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
    public double x =size.getWidth();
    public double y =size.getHeight();
    private JLabel labels[]= new JLabel[6];
    private JTextField text[]= new JTextField[3];
    private JPasswordField Ptext[]= new JPasswordField[2];
    private JButton CreateButton = new JButton("Create");
    private JButton BackButton = new JButton("Back");
    private ImageIcon icon;
    private Rectangle winSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    private Font f;
    private Container cp;
    private myGridBagConstraints GBC = new myGridBagConstraints();
    public GUICreateNewAccount() throws IOException
    {
        labels[0] = new JLabel ("Create New Account");
        labels[1]= new JLabel("Enter Your First Name Here:  ");
        labels[2]= new JLabel("Enter Your Last Name Here:  ");
        labels[3]= new JLabel("Enter Your Password Here:  ");
        labels[4]= new JLabel("Re-enter Your Password Here:  ");
        labels[5]= new JLabel("Enter Your Display Name Here:  ");
        for (int i=0;i<3;i++)
        text[i]=new JTextField(15);
        Ptext[0]=new JPasswordField(15);
        Ptext[1]=new JPasswordField(15);
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
        setSize((int)x,(int)y);
        f = new Font("Forte",1,30);
        
        icon = new ImageIcon(ImageIO.read(new File("Images\\12333798_998112436912236_1923610386_o.jpg")).getScaledInstance(winSize.width,winSize.height, 1));
        JLabel picture = new JLabel(icon);
        setContentPane(picture);
        
        cp = getContentPane();
        cp.setLayout(new GridBagLayout());
        GBC.addGBC(2, 0, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        labels[0].setForeground(Color.ORANGE);
        cp.add(labels[0],GBC);
        labels[0].setFont(f);
        GBC.addGBC(1, 3, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[1],GBC);
        f= new Font("Forte",0,20);
        labels[1].setFont(f);
        GBC.addGBC(3, 3, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(text[0],GBC);
        GBC.addGBC(1, 4, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[2],GBC);
        labels[2].setFont(f);
        GBC.addGBC(3, 4, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(text[1],GBC);
        GBC.addGBC(1, 5, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[3],GBC);
        labels[3].setFont(f);
        GBC.addGBC(3, 5, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(Ptext[0],GBC);
        GBC.addGBC(1, 7, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[4],GBC);
        labels[4].setFont(f);
        GBC.addGBC(3, 7, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(Ptext[1],GBC);
        GBC.addGBC(1, 8, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(labels[5],GBC);
        labels[5].setFont(f);
        GBC.addGBC(3, 8, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(text[2],GBC);
        GBC.addGBC(2, 9, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        cp.add(CreateButton,GBC);
        CreateButton.setFont(f);
        GBC.addGBC(1, 9, -1, -1, -1, -1, GridBagConstraints.CENTER, "");
        BackButton.setFont(f);
        cp.add(BackButton,GBC);
        this.CreateButton.addActionListener(new Handler());
        this.BackButton.addActionListener(new Handler());
    }
    
    private class Handler implements ActionListener
	{
		
		public void actionPerformed(ActionEvent e) 
		{
                    if(e.getSource().equals(CreateButton))
                    {
                    if(Ptext[0].getText().equals(Ptext[1].getText()))
                    {
                        Account one= new Account();
                        if(text[0].getText().equals("")||text[1].getText().equals("")||text[2].getText().equals("")||Ptext[0].getText().equals(""))
                        {
                            JOptionPane.showMessageDialog(null, "Invalid account, Try again","Alert",JOptionPane.ERROR_MESSAGE);
                            one.setFirstName(text[0].getText());
                            one.setLastName(text[1].getText());
                            one.setPassword(Ptext[0].getText());
                            one.setUserName(text[2].getText());
                       
                        }
                        
                        else
                        {
                            one.setFirstName(text[0].getText());
                            one.setLastName(text[1].getText());
                            one.setPassword(Ptext[0].getText());
                            one.setUserName(text[2].getText());
                        }
                        AccountFileManage afm = new AccountFileManage();
                      
                            if(afm.CreateNewAcc(one)==true)
                            {
                                JOptionPane.showMessageDialog(null, "Account already exists","Alert",JOptionPane.ERROR_MESSAGE);
                                text[2].setText("");
                            }
                            else 
                            {
                                Screens.AFM.WriteInFile(one);
                                Screens.P1.A = one;
                                Scc.Mm.setVisible(true);
				setVisible(false);
				dispose();
                            }
                       
                    }
                    else 
                    {
                        JOptionPane.showMessageDialog(null, "Password does not match","Alert",JOptionPane.ERROR_MESSAGE);
                        Ptext[0].setText("");
                        Ptext[1].setText("");
                    }
                    
		}
                if(e.getSource().equals(BackButton))
                {
                    Scc.Ln.setVisible(true);
                    setVisible(false);
                    dispose();
                   }
                }
   
	}
}
