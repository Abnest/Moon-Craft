package GUI;
import Terrans.*;
import User.*;
import java.awt.*;
import java.awt.color.ColorSpace;
import javax.swing.*;

import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
public class GUIMap extends JWindow {
    public Screens Scc = new Screens();
    boolean toSelect;
    public Point p1,p2;
    private JScrollPane scrollpane = new JScrollPane();
    private JButton[] button = new JButton [2];	
    public JLabel[] label = new JLabel [11];
    private Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
    public double x =size.getWidth();
    public double y =size.getHeight();
    private double hx = x/2.0;
    private double hy = y/2.0;
    public Container cont;
    private Color background = new Color (255,255,255);
    private Color team = Color.BLUE; //Youssef hna color men 3andak
    private Color health = Color.GREEN;
    private Font font = new Font("Serif", Font.BOLD, 50);
    private Font font2 = new Font("Serif", Font.BOLD, 35);
    public ArrayList <Terran> SelectedAll = new ArrayList();
    public Terran Selected = null;
    int xscroll=0;
    int yscroll=0;
    private SeigeTank ST= new SeigeTank(Color.RED);
    public int D=50;
    private Rectangle mapDimension;
    public JPanel PanelInfo= new JPanel();
    private Mineral[] M = new Mineral[20];
    private Gas[] G = new Gas[8];
     private Builder B;
    private boolean builderSelected=false;
     public Point CheckPoint(Point P,int i,JLabel J,int size){
        
                        
                            if (i%2==0)
                        return CheckPoint( new Point(P.x,P.y-50),++i,J,size);
                        else 
                        return CheckPoint( new Point(P.x-50,P.y),++i,J,size);
                        
          
}
	public int setX(int w,String pos){
		if(pos.equals("Left"))
			return  (int) (x-(x-w));
		else if(pos.equals("Right"))
			return (int) (x-w);
		else return 0;
		
	}
	public int setY(int h,String pos){
		if(pos.equals("Top"))
			return  (int) (y-(y-h));
		else if(pos.equals("Bottom"))
			return  (int) (y-h);
		else return 0;
		
	}
        public int setratiox(int w)
        {
            return (int)(x*(w/1920.0));
        }
        public int setratioy(int h)
        {
            return (int)(y*(h/1080.0));
        }
       public int setMapX(int w,String pos){
		if(pos.equals("Left"))
			return  (int) (4000-(4000-w));
		else if(pos.equals("Right"))
			return (int) (4000-w);
		else return 0;
		
	}
	public int setMapY(int h,String pos){
		if(pos.equals("Top"))
			return  (int) (4000-(4000-h));
		else if(pos.equals("Bottom"))
			return  (int) (4000-h);
		else return 0;
		
	}
	public GUIMap(){

            
            setSize((int)x,(int)y);
            //setExtendedState(JFrame.MAXIMIZED_BOTH);
            p1 = new Point ();
            p2 = new Point ();
            toSelect = false;
            x=(int)size.getWidth();
            y=(int)size.getHeight();
            button[0] = new JButton("Menu");
            button[1] = new JButton("Help");
            label[0] = new JLabel("Minerals "+Screens.P1.R.getMinerals());
		label[1] = new JLabel("Gas "+Screens.P1.R.getGas());
            label[2] = new JLabel("Limit");
            label[3] = new JLabel(new ImageIcon("Images\\MAP.jpg"))
            {
                public void paintComponent(Graphics g)
                {   
                    super.paintComponent(g);
                     if (toSelect == true)
                    {   
                     
                        
                           g.setColor(new Color((float)0.0,(float)0.191,(float)0.255,0.5f));
                           if (p1.x>p2.x&&p1.y>p2.y)
                           g.fillRect(p2.x, p2.y, Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
                           else if (p1.y>p2.y)
                           g.fillRect(p1.x,p2.y , Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));    
                           else if(p1.x>p2.x)
                           g.fillRect(p2.x, p1.y, Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
                           else
                           g.fillRect(p1.x, p1.y, Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
                          
                    }
           
              }
            };

            label[4] = new JLabel(new ImageIcon("Images\\Map - Small - Copy.jpg"));
            label[3].setAutoscrolls(true);
            scrollpane=new JScrollPane(label[3]);
            scrollpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
            scrollpane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            
            
            
            cont = getContentPane();
            cont.setLayout(null);
            cont.setBackground(background);
            cont.add(button[0]);
            cont.add(button[1]);
            cont.add(label[0]);
            cont.add(label[1]);
            cont.add(label[2]);
            cont.add(scrollpane);
            cont.add(label[4]);
            cont.add(PanelInfo);
            
            mapDimension= new Rectangle(setX(setratiox(5),"Left"),setY(setratioy(55),"Top"), (int) (x-setratiox(10)), (int) (y-(y/3)));
            scrollpane.setBounds(mapDimension);
            button[0].setBounds(setX(setratiox(5),"Left"), setY(setratioy(5),"Top"), setratiox(150), setratioy(40));
            button[1].setBounds(setX(setratiox(160),"Left"), setY(setratioy(5),"Top"), setratiox(150),setratioy(40));
           label[0].setBounds(setX(setratiox(500),"Right"),setY(setratioy(5),"Top"), setratiox(200), setratioy(40));
            label[1].setBounds(setX(setratiox(350),"Right"),setY(setratioy(5),"Top"), setratiox(200), setratioy(40));
		//label[2].setBounds(setX(setratiox(50),"Right"),setY(setratioy(5),"Top"),setratiox(70), setratioy(40));
            label[4].setBounds(setX(setratiox(20),"Left"),setY(setratioy(300),"Bottom"), setratiox(250), setratioy(250));
            setMGmap();
            setPlayer();
            
            prepareArmy();
            
            label[3].addMouseListener(new MouseWatcher());
            button[0].addActionListener(new buttonWatcher());
            button[1].addActionListener(new buttonWatcher());
            
            
            MouseAdapter Pan = new MouseAdapter() {
                
                private Point start;		
                
                public void mousePressed(MouseEvent e) {
                    if(SwingUtilities.isRightMouseButton(e))
                    start = new Point(e.getPoint());
                }
                
                public void mouseReleased(MouseEvent e) {
                if (toSelect == true)
                {
                    SelectedAll.clear();
                    Rectangle R = new Rectangle();
                           if (p1.x>p2.x&&p1.y>p2.y)
                           R =new Rectangle(p2.x, p2.y, Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
                           else if (p1.y>p2.y)
                           R =new Rectangle(p1.x,p2.y , Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));    
                           else if(p1.x>p2.x)
                           R =new Rectangle(p2.x, p1.y, Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
                           else
                           R =new Rectangle(p1.x, p1.y, Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
                           p1 = R.getLocation();
                           p2 = new Point(p1.x+R.width,p1.y+R.height);
                    for (int i =p1.x ; i<p2.x;i++)
                        for (int j= p1.y ; j < p2.y;j++)
                        {
                            
                            if( label[3].getComponentAt(i, j)!= label[3])
                            {try{
                             if (label[3].getComponentAt(i, j)!=null)
                            {
                                
                                Terran T = (Terran) label[3].getComponentAt(i, j);
                                if (SelectedAll.size() == 0)
                                    SelectedAll.add(T);
                                else if (SelectedAll.indexOf(T)==-1)
                                        SelectedAll.add(T);
                               }
                           }catch(ClassCastException ex)
                           {
                              
                           }}
                        }
                    toSelect=false;
                    label[3].repaint();
                    
                }
                }
                
                public void mouseDragged(MouseEvent e) {
                  if(SwingUtilities.isRightMouseButton(e))
                  {
                    if (start != null) {
                        JViewport viewPort = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class,  label[3]);
                        if (viewPort != null) {
                            int movingX = start.x - e.getX();
                            int movingY = start.y - e.getY();
                            
                            Rectangle view = viewPort.getViewRect();
                            view.x += movingX;
                            view.y += movingY;
                            
                            label[3].scrollRectToVisible(view);
                           /* label[3].getX();
                            label[3].getY();*/
                            }
                        }
                    }
                    if(SwingUtilities.isLeftMouseButton(e))
                                {
                                    p2= e.getLocationOnScreen();
                                    p2.x-=label[3].getX();
                                    p2.y-=label[3].getY();
                                    label[3].repaint();
                                }
                }};
            
            label[3].addMouseListener(Pan);
            label[3].addMouseMotionListener(Pan);
            repaint();
      
	}
      public void setMGmap()
      {
          
                for(int i = 0;i<20;i++){
                    M[i] = new Mineral();
                    M[i].setImage();
                    M[i].addMouseListener(new MouseWatcher());
                }
                
                for(int i = 0;i<8;i++){
                    G[i] = new Gas();
                    G[i].setImage();
                    G[i].addMouseListener(new MouseWatcher());
                }
                label[3].add(M[0]);
                M[0].setBounds(setMapX(setratiox(157),"Left"),setMapY(setratioy(68),"Top"), M[0].getSize().width, M[0].getSize().height);
                
                label[3].add(M[1]);
                M[1].setBounds(setMapX(setratiox(114),"Left"),setMapY(setratioy(86),"Top"), M[1].getSize().width, M[1].getSize().height);
                
                label[3].add(M[2]);
                M[2].setBounds(setMapX(setratiox(186),"Left"),setMapY(setratioy(32),"Top"), M[2].getSize().width, M[2].getSize().height);
                
                label[3].add(M[3]);
                M[3].setBounds(setMapX(setratiox(298),"Left"),setMapY(setratioy(38),"Top"), M[3].getSize().width, M[3].getSize().height);
                
                label[3].add(M[4]);
                M[4].setBounds(setMapX(setratiox(247),"Left"),setMapY(setratioy(62),"Top"), M[4].getSize().width, M[4].getSize().height);
                
                 label[3].add(M[5]);
                M[5].setBounds(setMapX(setratiox(157),"Right"),setMapY(setratioy(68),"Top"), M[5].getSize().width, M[5].getSize().height);
                
                label[3].add(M[6]);
                M[6].setBounds(setMapX(setratiox(114),"Right"),setMapY(setratioy(86),"Top"), M[6].getSize().width, M[6].getSize().height);
                
                label[3].add(M[7]);
                M[7].setBounds(setMapX(setratiox(186),"Right"),setMapY(setratioy(32),"Top"), M[7].getSize().width, M[7].getSize().height);
                
                label[3].add(M[8]);
                M[8].setBounds(setMapX(setratiox(298),"Right"),setMapY(setratioy(38),"Top"), M[8].getSize().width, M[8].getSize().height);
                
                label[3].add(M[9]);
                M[9].setBounds(setMapX(setratiox(247),"Right"),setMapY(setratioy(62),"Top"), M[9].getSize().width, M[9].getSize().height);

                
                label[3].add(M[10]);
                M[10].setBounds(setMapX(setratiox(157),"Left"),setMapY(setratioy(108),"Bottom"), M[10].getSize().width, M[10].getSize().height);
                
                label[3].add(M[11]);
                M[11].setBounds(setMapX(setratiox(114),"Left"),setMapY(setratioy(126),"Bottom"), M[11].getSize().width, M[11].getSize().height);
                
                label[3].add(M[12]);
                M[12].setBounds(setMapX(setratiox(186),"Left"),setMapY(setratioy(72),"Bottom"), M[12].getSize().width, M[12].getSize().height);
                
                label[3].add(M[13]);
                M[13].setBounds(setMapX(setratiox(298),"Left"),setMapY(setratioy(78),"Bottom"), M[13].getSize().width, M[13].getSize().height);
                
                label[3].add(M[14]);
                M[14].setBounds(setMapX(setratiox(247),"Left"),setMapY(setratioy(102),"Bottom"), M[14].getSize().width, M[14].getSize().height);
                
                label[3].add(M[15]);
                M[15].setBounds(setMapX(setratiox(157),"Right"),setMapY(setratioy(108),"Bottom"), M[15].getSize().width, M[15].getSize().height);
                
                label[3].add(M[16]);
                M[16].setBounds(setMapX(setratiox(114),"Right"),setMapY(setratioy(126),"Bottom"), M[16].getSize().width, M[16].getSize().height);
                
                label[3].add(M[17]);
                M[17].setBounds(setMapX(setratiox(186),"Right"),setMapY(setratioy(72),"Bottom"), M[17].getSize().width, M[17].getSize().height);
                
                label[3].add(M[18]);
                M[18].setBounds(setMapX(setratiox(298),"Right"),setMapY(setratioy(78),"Bottom"), M[18].getSize().width, M[18].getSize().height);
                
                label[3].add(M[19]);
                M[19].setBounds(setMapX(setratiox(247),"Right"),setMapY(setratioy(102),"Bottom"), M[19].getSize().width, M[19].getSize().height);
                
                label[3].add(G[0]);
                G[0].setBounds(setMapX(setratiox(80),"Left"),setMapY(setratioy(135),"Top"), G[0].getSize().width, G[0].getSize().height);
                
                label[3].add(G[1]);
                G[1].setBounds(setMapX(setratiox(356),"Left"),setMapY(setratioy(50),"Top"), G[1].getSize().width, G[1].getSize().height);
                
                label[3].add(G[2]);
                G[2].setBounds(setMapX(setratiox(80),"Right"),setMapY(setratioy(135),"Top"), G[2].getSize().width, G[2].getSize().height);
                
                label[3].add(G[3]);
                G[3].setBounds(setMapX(setratiox(356),"Right"),setMapY(setratioy(50),"Top"), G[3].getSize().width, G[3].getSize().height);
                
                label[3].add(G[4]);
                G[4].setBounds(setMapX(setratiox(80),"Left"),setMapY(setratioy(170),"Bottom"), G[4].getSize().width, G[4].getSize().height);
                
                label[3].add(G[5]);
                G[5].setBounds(setMapX(setratiox(356),"Left"),setMapY(setratioy(50),"Bottom"), G[5].getSize().width, G[5].getSize().height);
                
                label[3].add(G[6]);
                G[6].setBounds(setMapX(setratiox(80),"Right"),setMapY(setratioy(170),"Bottom"), G[6].getSize().width, G[6].getSize().height);
                
                label[3].add(G[7]);
                G[7].setBounds(setMapX(setratiox(356),"Right"),setMapY(setratioy(50),"Bottom"), G[7].getSize().width, G[7].getSize().height);
                
                
                
      }
      public void setPlayer()
      {
           
                Screens.P1.dum.CdCr.add(new CommandCenter(Screens.P1.ChoosenColor));
                Selected = Screens.P1.dum.CdCr.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setX(setratiox(206),"Left"),setY(setratioy(150),"Top"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P1.dum.BS.add(new Builder(Screens.P1.ChoosenColor));
                Selected = Screens.P1.dum.BS.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setX(setratiox(800),"Left"),setY(setratioy(330),"Top"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;

                Screens.P1.dum.BS.add(new Builder(Screens.P1.ChoosenColor));
                Selected = Screens.P1.dum.BS.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setX(setratiox(800),"Left"),setY(setratioy(380),"Top"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P1.dum.BS.add(new Builder(Screens.P1.ChoosenColor));
                Selected = Screens.P1.dum.BS.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setX(setratiox(800),"Left"),setY(setratioy(430),"Top"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P1.dum.BS.add(new Builder(Screens.P1.ChoosenColor));
                Selected = Screens.P1.dum.BS.get(3);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setX(setratiox(800),"Left"),setY(setratioy(480),"Top"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P1.dum.BS.add(new Builder(Screens.P1.ChoosenColor));
                Selected = Screens.P1.dum.BS.get(4);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setX(setratiox(800),"Left"),setY(setratioy(530),"Top"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
      }
      public void paint(Graphics g)
      {
            PanelInfo.removeAll();
            
            if (Selected != null)
            { 
              PanelInfo=new JPanel();
              Selected.setInfo();
              PanelInfo=Selected.Info;
              PanelInfo.setBounds(setX(setratiox(700),"Left"),(setY(setratioy(250),"Bottom")),(setratiox(1000)),(setratioy(200)));
              cont.remove(PanelInfo);
              cont.add(PanelInfo);
              revalidate();
            }
            else
            {
              PanelInfo=new JPanel();
              PanelInfo.setBounds(setX(setratiox(700),"Left"),(setY(setratioy(250),"Bottom")),(setratiox(1000)),(setratioy(200)));
              cont.remove(PanelInfo);
              cont.add(PanelInfo);
              revalidate();
              
            }
           
            revalidate();
            super.paint(g);
        }
      public void prepareArmy()
      {
                Screens.P2.dum.CdCr.add(new CommandCenter(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.CdCr.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(420),"Right"),setMapY(setratioy(380),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.CdCr.add(new CommandCenter(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.CdCr.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1080),"Right"),setMapY(setratioy(900),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(480),"Right"),setMapY(setratioy(400),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(540),"Right"),setMapY(setratioy(430),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(710),"Right"),setMapY(setratioy(520),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(3);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(130),"Right"),setMapY(setratioy(580),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(4);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(610),"Right"),setMapY(setratioy(140),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(5);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(640),"Right"),setMapY(setratioy(320),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(6);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1200),"Right"),setMapY(setratioy(690),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(7);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1430),"Right"),setMapY(setratioy(780),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(8);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1220),"Right"),setMapY(setratioy(1130),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(9);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(970),"Right"),setMapY(setratioy(760),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(810),"Right"),setMapY(setratioy(420),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(560),"Right"),setMapY(setratioy(317),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(311),"Right"),setMapY(setratioy(242),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(3);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1190),"Right"),setMapY(setratioy(967),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(4);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(480),"Right"),setMapY(setratioy(610),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(5);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(430),"Right"),setMapY(setratioy(890),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(6);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(870),"Right"),setMapY(setratioy(720),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.R.add(new Reaper(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.R.get(7);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1280),"Right"),setMapY(setratioy(410),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.ST.add(new SeigeTank(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.ST.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1280),"Right"),setMapY(setratioy(321),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.ST.add(new SeigeTank(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.ST.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(210),"Right"),setMapY(setratioy(598),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.ST.add(new SeigeTank(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.ST.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(870),"Right"),setMapY(setratioy(946),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.ST.add(new SeigeTank(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.ST.get(3);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(781),"Right"),setMapY(setratioy(742),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.ST.add(new SeigeTank(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.ST.get(4);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(539),"Right"),setMapY(setratioy(890),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BR.add(new Bunker(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BR.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(760),"Right"),setMapY(setratioy(354),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BR.add(new Bunker(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BR.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1380),"Right"),setMapY(setratioy(713),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BR.add(new Bunker(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BR.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1624),"Right"),setMapY(setratioy(275),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.H.add(new Hellion(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.H.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1720),"Right"),setMapY(setratioy(261),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.H.add(new Hellion(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.H.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1230),"Right"),setMapY(setratioy(415),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.H.add(new Hellion(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.H.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1170),"Right"),setMapY(setratioy(741),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.FY.add(new Factory(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.FY.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(536),"Right"),setMapY(setratioy(820),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.FY.add(new Factory(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.FY.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1047),"Right"),setMapY(setratioy(274),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.FY.add(new Factory(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.FY.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(984),"Right"),setMapY(setratioy(480),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.MT.add(new MissileTurret(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.MT.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(187),"Right"),setMapY(setratioy(1030),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.MT.add(new MissileTurret(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.MT.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(452),"Right"),setMapY(setratioy(123),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.MT.add(new MissileTurret(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.MT.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1360),"Right"),setMapY(setratioy(912),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BK.add(new Barrack(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BK.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1197),"Right"),setMapY(setratioy(602),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BK.add(new Barrack(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BK.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(894),"Right"),setMapY(setratioy(190),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BK.add(new Barrack(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BK.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(260),"Right"),setMapY(setratioy(492),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BS.add(new Builder(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BS.get(0);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1360),"Right"),setMapY(setratioy(480),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BS.add(new Builder(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BS.get(1);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1410),"Right"),setMapY(setratioy(746),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BS.add(new Builder(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BS.get(2);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(752),"Right"),setMapY(setratioy(890),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.BS.add(new Builder(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.BS.get(3);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1250),"Right"),setMapY(setratioy(219),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(10);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1624),"Right"),setMapY(setratioy(312),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(11);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1604),"Right"),setMapY(setratioy(340),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(12);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1514),"Right"),setMapY(setratioy(400),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(13);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1550),"Right"),setMapY(setratioy(431),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(14);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1600),"Right"),setMapY(setratioy(380),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(15);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1680),"Right"),setMapY(setratioy(467),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(16);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1617),"Right"),setMapY(setratioy(487),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
                
                Screens.P2.dum.M.add(new Marine(Screens.P2.ChoosenColor));
                Selected = Screens.P2.dum.M.get(17);
                label[3].add(Selected);
                Selected.addMouseListener(new MouseWatcher());
                Selected.setBounds(setMapX(setratiox(1700),"Right"),setMapY(setratioy(520),"Bottom"),  Selected.getSize().width, Selected.getSize().height);
                Selected.Pos = new Point (Selected.getX(),Selected.getY());
                Selected= null;
        }

      
       public void build(Terran T)
       {
    	   Selected = T;
    	   Selected.addMouseListener(new MouseWatcher());
           
       }
       
	private class MouseWatcher implements MouseListener, MouseMotionListener{
		AMove MoveSelected;
                IAttack AttackSelected;
		public void mouseClicked (MouseEvent e)
                {
                    try
                    {
                        B = (Builder) Selected;
                        builderSelected=true;
                    }catch(ClassCastException ex)
                    {
                        
                    }
                    if(e.getSource().equals(label[3]))
                        {	
                                if(SwingUtilities.isRightMouseButton(e))
                                {   if (SelectedAll.size()==0)
                                    {
                                        MoveSelected= null;
                                    MoveSelected= (AMove) Selected;
                                    MoveSelected.changePosition(new Point(e.getX()-D/2,e.getY()-D/2));
                                    }
                                else 
                                {   
                                    Point p= e.getLocationOnScreen();
                                    p.x-=label[3].getX();
                                    p.y-=label[3].getY();
                                    for (int i = 0 ; SelectedAll.size()>i ;i++)
                                        try
                                        {
                                            JLabel J = SelectedAll.get(i);
                                          AMove A = (AMove)SelectedAll.get(i);
                                               if (i%2==0)
                                               {
                                                   p = new Point(p.x,p.y-A.getWidth());
                                                   A.changePosition(p);
                                               }
                                           else{                                                  
                                                   p = new Point(p.x-A.getHealth(),p.y);
                                                   A.changePosition(p);
                                               }
                                             }catch(ClassCastException ex)
                                        {}
                                    
                                }
                                }
                                if(SwingUtilities.isLeftMouseButton(e))
                                {
                                    SelectedAll.clear();
                                    Selected = null;
                                    AttackSelected=null;
                                    MoveSelected= null;
                                    repaint();
            
                                }
                                
                        }
                    else
                    {
                         if (Selected==null)
                           {
                           if(SwingUtilities.isLeftMouseButton(e))
                                {
                                    SelectedAll.clear();
                                    Selected = null;
                                    Selected = (Terran) e.getSource();
                                    repaint();
                                }

                            }   
                         else if(builderSelected)  
                                {if(SwingUtilities.isRightMouseButton(e))
                                { 
                                    try
                                    {
                                        Gas g=(Gas)e.getSource();
                                        B.seekGas(Screens.P1.R,g);
                                    }
                                    catch(ClassCastException ex)
                                    {}
                                    
                                   try
                                    {
                                        Mineral m=(Mineral)e.getSource();
                                        B.seekMinerals(Screens.P1.R,m);
                                    }
                                    catch(ClassCastException ex)
                                    {}    
                                   
                                builderSelected= false;
                                }
			}
                          
                            {
                                if(SwingUtilities.isLeftMouseButton(e))
                                {
                                    builderSelected= false;
                                    SelectedAll.clear();
                                    Selected = null;
                                    Selected = (Terran) e.getSource();
                                    repaint();
                                }
                                if(SwingUtilities.isRightMouseButton(e))
                                {   
                                    Terran Attacked=(Terran) e.getSource();
                                    if (Attacked.Team== Color.BLUE)
                                    {if (SelectedAll.size()==0)
                                    {
                                    AttackSelected = null;
                                    AttackSelected = (IAttack) Selected;
                                    AttackSelected.Attack(Attacked);
                                
                                    }
                                    else
                                    {
                                        for (int i = 0 ; SelectedAll.size()>i ;i++)
                                        try
                                        {
                                          IAttack A = (IAttack)SelectedAll.get(i);
                                          A.Attack(Attacked);
                                           
                                        }catch(ClassCastException ex)
                                        {}
                                        
                                    }
                                }
                                }
                            }
                    }
		}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
		public void mousePressed(MouseEvent e) {
                if(SwingUtilities.isLeftMouseButton(e))
                {
                    /* label[3].getX();
                    label[3].getY();*/
                    toSelect = true;
                    p1= e.getLocationOnScreen();
                    p1.x-=label[3].getX();
                    p1.y-=label[3].getY();
                    p2= e.getLocationOnScreen();
                    p2.x-=label[3].getX();
                    p2.y-=label[3].getY();
                }
                }
		public void mouseReleased(MouseEvent e) {
                if(SwingUtilities.isLeftMouseButton(e))
                {
                }
                }
                public void mouseDragged(MouseEvent e) {
			
                    if(e.getSource().equals(label[3])){	
                        { if(SwingUtilities.isRightMouseButton(e))
                                {
                                    MoveSelected= (AMove) Selected;
                                    MoveSelected.changePosition(new Point(e.getX()-D/2,e.getY()-D/2));
                                }
                                if(SwingUtilities.isLeftMouseButton(e))
                                {
                                    p2= e.getLocationOnScreen();
                                    p2.x-=label[3].getX();
                                    p2.y-=label[3].getY();
                                    label[3].repaint();
                                    Selected = null;
                                    MoveSelected= null;
                                    
                                }
			}
                    }
			
		}
		public void mouseMoved(MouseEvent e) {}
		}

private class buttonWatcher implements ActionListener
{
    public void actionPerformed(ActionEvent e) 
		{
			if(e.getSource()==button[0])
			{
				Scc.MpM.setVisible(true);
				
			}
			
			else if(e.getSource()==button[1])
			{
				Scc.In.setVisible(true);
			}
		}
		
}
}