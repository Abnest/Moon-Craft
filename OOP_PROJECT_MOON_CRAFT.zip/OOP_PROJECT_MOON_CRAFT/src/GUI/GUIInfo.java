package GUI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
/**
 *
 * @author Bringyyy
 */
public class GUIInfo extends JFrame{
    
    private myHandler handler;
    private JLabel l[];
    private JLabel l2[];
    private JButton b[];
    private JTabbedPane tabbedPane;
    private JPanel cards[];
    
    public GUIInfo()
    {  
        tabbedPane= new JTabbedPane();
        l= new JLabel[10];
        l2= new JLabel[10];
        b= new JButton[10];
       handler = new myHandler();
        cards= new JPanel[10];
        for(int i=0; i<10; i++)
    {
        cards[i] = new JPanel(){
            public Dimension getPreferredSize() {
                Dimension size = super.getPreferredSize();
                size.width += 900;
                size.height+=700;
                return size;
            }
        };
        
    }   Font f = new Font("Ariel",Font.BOLD| Font.ITALIC|Font.LAYOUT_LEFT_TO_RIGHT,18);
       
      
        
         for(int i=0; i<10; i++)
    {
        switch(i)
        {
            case 0:{
                l[i]= new JLabel("Produces Builders and serves as a drop off point for processing of minerals and gas.");
               l2[i]= new JLabel( "Each Command Center you build, starts you off with five builders to get you started.");
                l[i].setFont(f);
                l2[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\Command_Center.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
               l[i].setVisible(false);
               l2[i].setVisible(false);
                
                b[i]= new JButton("Command Center");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                cards[i].add(l2[i]).setBounds(275, 60, 600, 25);
                break;
            }
            case 1:{
                l[i]= new JLabel("Produces Terran infantry units like Marines and Reapers.");
                 l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Barracks.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
               l[i].setVisible(false);
                
                b[i]= new JButton("Barrack");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }
           case 2:{
                l[i]= new JLabel("Provides protection for Terran infantry.");
                  l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Bunker.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
               l[i].setVisible(false);
                
                b[i]= new JButton("Bunker");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }
           case 3:  {
                l[i]= new JLabel("Produces Terran vehicle units like Hellions and SeigeTanks.");
                 l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Factory.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
                l[i].setVisible(false);
                
                b[i]= new JButton("Factory");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }  
           case 4:  {
                l[i]= new JLabel("Formerly known as the Jackal, ");
                l2[i]= new JLabel("this fast vehicle is armed with a MachineGun suited for destroying masses of weaker units.");
                 l[i].setFont(f);
                 l2[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Hellion.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
                l[i].setVisible(false);
               l2[i].setVisible(false);
                
                b[i]= new JButton("Hellion");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                cards[i].add(l2[i]).setBounds(275, 60, 600, 25);
                break;
            }   
           case 5: {
                l[i]= new JLabel("Anti-air Turret that fires two Missiles at a time.");
                l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\MissileTurret_SC2_Rend1.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
                l[i].setVisible(false);
                
                b[i]= new JButton("MissileTurret");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                
                break;
            }    
           case 6: {
                l[i]= new JLabel("Terran tank that can strike targets at a greater range.");
                 l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\SiegeTank.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
               l[i].setVisible(false);
                
                b[i]= new JButton("SiegeTank");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }    
           case 7:{
                l[i]= new JLabel("The builder and resource gatherer of the Terran race.");
                 l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Builder.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
                l[i].setVisible(false);
                
                b[i]= new JButton("Builder");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }     
           case 8:{
                l[i]= new JLabel("The basic Terran infantry.");
                 l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Marine.png").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
                l[i].setVisible(false);
                
                b[i]= new JButton("Marine");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }     
           case 9:  {
                l[i]= new JLabel("Exceptionally fast infantry that uses Missiles.");
                 l[i].setFont(f);
                JLabel I= new JLabel();
                I.setIcon(new ImageIcon(new ImageIcon("Images\\\\Reaper.jpg").getImage().getScaledInstance(300,300 , Image.SCALE_DEFAULT))); 
                l[i].setVisible(false);
                
                b[i]= new JButton("Reaper");
                b[i].setFont(f);
                b[i].addActionListener(handler);
                
                cards[i].setLayout(new FlowLayout());
                cards[i].add(b[i]).setBounds(70, 25, 200, 75);
                
                cards[i].add(I).setBounds(25,125,300,300);
                cards[i].add(l[i]).setBounds(275, 25,800,25);
                break;
            }  
        }
        
    }   
        tabbedPane.addTab("Command Center", cards[0]);
        tabbedPane.addTab("Barrack", cards[1]);
        tabbedPane.addTab("Bunker", cards[2]);
        tabbedPane.addTab("Factory", cards[3]);
        tabbedPane.addTab("Hellion", cards[4]);
        tabbedPane.addTab("Missile Turret", cards[5]);
        tabbedPane.addTab("SeigeTank", cards[6]);
        tabbedPane.addTab("Builder", cards[7]);
        tabbedPane.addTab("Marine", cards[8]);
        tabbedPane.addTab("Reaper", cards[9]);

        setSize(900,600);
        
         getContentPane().add(tabbedPane);
       // setResizable(false);
       
        
    }
    
    private class myHandler implements ActionListener{

        public void actionPerformed(ActionEvent e) {
        Object x= e.getSource();
        for(int i=0; i<10;i++)
            if(x.equals(b[i]))
                {
            l[i].setVisible(true);
            if(l2[i]!=null)
            l2[i].setVisible(true);
              }
        }
        
    }
 }

