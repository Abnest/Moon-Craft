

package Manage_files;
import java.io.Serializable;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.lang.NullPointerException;
import java.lang.ExceptionInInitializerError;

public class EncryptionDecryption implements Serializable {
	//Keys should be within 1-6 depending on the number of Characters in the string ( 1-6 for the maximum which is 142 )
		public String Encrypt(String word, int key)
		{
			String resultlvl1 = "";
			String resultlvl2 = "";
			String resultlvl3 = "";
			HashMap<Character, String> Table = new HashMap<Character, String>(224);
			
			for(int i =0;i<word.length();i++)
				resultlvl1+= (char)(word.charAt(i)+(key+i));
				
			int j=256;
			for(int i =0;i<256;i++){
				Table.put((char)i, String.valueOf(j*key));
				j--;
			}
			
			for(int i =0;i<resultlvl1.length();i++)
				resultlvl2+= Table.get(resultlvl1.charAt(i)) + '`';
			
			
			for(int i =0;i<resultlvl2.length();i++)
				resultlvl3+= (char)(resultlvl2.charAt(i)+(key+i));
			
			return resultlvl3;
		}
		
		
		public String Decrypt(String result, int key)
		{
			String strlvl1 = "";
			String strlvl2 = "";
			String strlvl3 = "";
			HashMap<String, Character> Table = new HashMap<String, Character>(224);
			
			for(int i =0;i<result.length();i++)
				strlvl1+= (char)(result.charAt(i)-(key+i));
			
			
			StringTokenizer strlvl2ST = new StringTokenizer(strlvl1, "`");
	
			int j=256;
			for(int i =0;i<256;i++){
				Table.put(String.valueOf(j*key), (char)i);
				j--;
			}
			while(strlvl2ST.hasMoreTokens()){
				strlvl2+=Table.get(strlvl2ST.nextToken());
			}
			
			
			for(int i =0;i<strlvl2.length();i++)
				strlvl3+= (char)(strlvl2.charAt(i)-(key+i));
			
			return strlvl3;
		}
	}
