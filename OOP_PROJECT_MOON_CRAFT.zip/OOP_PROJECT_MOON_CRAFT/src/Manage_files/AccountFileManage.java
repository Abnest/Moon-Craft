package Manage_files;
import User.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AccountFileManage implements Serializable
{    	
    public boolean CreateNewAcc(Account a) 
    {
        ObjectInputStream in = null;
        String Filename=a.getUserName();
        try {
            File FOS = new File(Filename);
            in = new ObjectInputStream(new FileInputStream(FOS));
            Account a1=new Account();
            while(true)
            {
                a1= (Account)in.readObject();
                if(a.getUserName().equals(a1.getUserName()))
                    return true;
                
            }  
            //  in.close();
        } catch (IOException ex) {
           return false;
        } catch (ClassNotFoundException ex) {
             return false;
        }
        
    }
    
    public boolean WriteInFile(Account a)
    {
        String Filename = a.getUserName();
        ObjectOutputStream out;
        try {
            out = new ObjectOutputStream(new FileOutputStream(Filename));
            out.writeObject(a);
            out.close();
            return true;
        } catch (IOException ex) {
            return false;
        }
        
    }
    public boolean CheckOccuranceAccount(Account a) throws FileNotFoundException, ClassNotFoundException, IOException
	{		
		
		Account f=new Account();
                String Filename = a.getUserName();
		ObjectInputStream in=new ObjectInputStream(new FileInputStream(Filename));
		while(true)
                {
                f = (Account) in.readObject();
		if(a.getUserName().equals(f.getUserName()))
		   {
			if(a.getPassword().equals(f.getPassword()))
                        {
                           
                            return true;
                        }
			
			else
                        return false;

                   }
                return false;
                }
                
                
	}
    
    
    
    
    }
    

