
package Manage_files;
import User.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ManageSaveAndLoad
{

    public boolean SaveData(Player P)
    {
        
        try {
            File FOS = new File("saves\\"+P.A.getUserName());
            ObjectOutputStream BW;
            
            BW = new ObjectOutputStream(new FileOutputStream(FOS));
            BW.writeObject(P);
            BW.close();
            return true;
        } catch (IOException ex) {
            
            Logger.getLogger(ManageSaveAndLoad.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }
    public Player LoadData(String Name) throws IOException, ClassNotFoundException
    {  
       ObjectInputStream BW=new ObjectInputStream(new FileInputStream("saves\\"+Name));
       return (Player)BW.readObject();
    }
};
